/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   funcionesCarga.h
 * Author: Alonso
 *
 * Created on 18 de junio de 2021, 10:49 AM
 */

#ifndef FUNCIONESCARGA_H
#define FUNCIONESCARGA_H
#include "ClaseConductor.h"

void leerConductores(ClaseConductor *conductor,int &numConductores);
void leerYAsignarFaltas(ClaseConductor *conductor,int numConductores);
void leerYCompletarInfracciones(ClaseConductor *conductor,int numConductores);
void calcularMonto(ClaseConductor *conductor,int numConductores);
void emitirReporte(ClaseConductor *conductor,int numConductores);
void aplicarAmnistia(ClaseConductor *conductor,int numConductores);
void emitirReporteConAministia(ClaseConductor *conductor,int numConductores);

#endif /* FUNCIONESCARGA_H */

