/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   sobrecarga.cpp
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 18 de junio de 2021, 08:32 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
using namespace std;
#include "ClaseConductor.h"
#include "ClaseFalta.h"
#include "ClaseFaltaCond.h"
#include "ClaseInfraccion.h"
#include "sobrecarga.h"
#include "funciones.h"
#define MAX_LINEA 200

ifstream & operator >>(ifstream &in, ClaseConductor &conductor){
    int licencia;
    char nombre[100];
    in>>licencia;
    if(in.eof()) return in;
    conductor.SetLicencia(licencia);
    in.get();
    in.getline(nombre,100);
    conductor.SetNombre(nombre);
    
    return in;
}

ifstream & operator >>(ifstream &in, ClaseFalta &falta){
    int licencia,dd,mm,aa,fecha,codInfraccion;
    char placa[100],car;
    in>>licencia;
    if(in.eof()) return in;
    falta.SetLicencia(licencia);
    in.get();
    in.getline(placa,100,',');
    falta.SetPlaca(placa);
    in>>dd>>car>>mm>>car>>aa;
    fecha=aa*10000+mm*100+dd;
    falta.SetFecha(fecha);
    in.get();
    in>>codInfraccion;
    falta.SetCodInf(codInfraccion);
    
    return in;
}

ifstream & operator >>(ifstream &in, ClaseInfraccion &infraccion){
    int codigo;
    char descripcion[500],gravedad[50];
    double multa;
    in>>codigo;
    if(in.eof()) return in;
    infraccion.SetCodigo(codigo);
    in.get();
    in>>descripcion;
    in.getline(descripcion,500,',');
    infraccion.SetDescripcion(descripcion);
    in.getline(gravedad,50,',');
    infraccion.SetGravedad(gravedad);
    in>>multa;
    infraccion.SetMulta(multa);
    
    return in;
}

ofstream & operator <<(ofstream &out,const ClaseConductor &conductor){
    int numFaltas=0,dd,mm,aa;
    char nombre[100],placa[50],gravedad[50];
    ClaseFaltaCond falta;
    
    out.precision(2);
    out<<fixed;
    
    conductor.GetNombre(nombre);
    out<<"Conductor: "<<nombre<<endl;
    out<<"Licencia No.: "<<conductor.GetLicencia()<<endl;
    imprimirLinea('=',MAX_LINEA,out);
    out<<"Infracciones cometidas: "<<endl;
    imprimirLinea('-',MAX_LINEA,out);
    out<<"No."<<setw(20)<<"Fecha"<<setw(20)<<"Placa"<<setw(20)<<"Infraccion"<<setw(20)<<"Gravedad"<<setw(20)<<"Multa"<<endl;
    numFaltas=conductor.GetNumFaltas();
    for(int i=0;i<numFaltas;i++){
        conductor.GetLFaltas(falta,i);
        falta.GetPlaca(placa);
        falta.GetGravedad(gravedad);
        convertirFecha(dd,mm,aa,falta.GetFecha());
        out<<setw(2)<<i+1<<")"<<setw(13)<<" "<<setfill('0')<<setw(2)<<dd<<"/"<<setw(2)<<mm<<"/"<<setw(4)<<aa<<setfill(' ')<<setw(19)<<placa<<setw(15)<<falta.GetCodInf()
                <<setw(21)<<gravedad<<setw(21)<<falta.GetMulta()<<endl;
    }
    imprimirLinea('=',MAX_LINEA,out);
    out<<setw(40)<<"Cantidad"<<setw(20)<<"Total"<<endl;
    out<<"Total de Infracciones: "<<setw(13)<<" "<<numFaltas<<setw(24)<<conductor.GetMontoTotal()<<endl;
}