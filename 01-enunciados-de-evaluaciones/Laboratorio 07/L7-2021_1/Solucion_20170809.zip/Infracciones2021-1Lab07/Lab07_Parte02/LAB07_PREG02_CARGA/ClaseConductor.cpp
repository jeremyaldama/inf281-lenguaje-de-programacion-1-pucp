/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ClaseConductor.cpp
 * Author: Alonso
 * 
 * Created on 18 de junio de 2021, 08:05 AM
 */

#include <cstring>
#include "ClaseFaltaCond.h"
#include "ClaseConductor.h"
#include "ClaseFalta.h"

ClaseConductor::ClaseConductor() {
    licencia=0;
    nombre=nullptr;
    numFaltas=0;
    montoTotal=0.0;
}

ClaseConductor::ClaseConductor(const ClaseConductor& orig) {
}

ClaseConductor::~ClaseConductor() {
}

void ClaseConductor::SetMontoTotal(double montoTotal) {
    this->montoTotal = montoTotal;
}

double ClaseConductor::GetMontoTotal() const {
    return montoTotal;
}

void ClaseConductor::SetNumFaltas(int numFaltas) {
    this->numFaltas = numFaltas;
}

int ClaseConductor::GetNumFaltas() const {
    return numFaltas;
}

void ClaseConductor::SetLfaltas(const ClaseFaltaCond &falta) {
    lfaltas[numFaltas]=falta;
    numFaltas++;
}

void ClaseConductor::GetLFaltas(ClaseFaltaCond& falta, int i) const {
    falta=lfaltas[i];
}


void ClaseConductor::SetNombre(char* aux) {
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(aux)+1];
    strcpy(nombre,aux);
}

void ClaseConductor::GetNombre(char *aux) const {
    if(nombre==nullptr) aux[0]=0;
    strcpy(aux,nombre);
}

void ClaseConductor::SetLicencia(int licencia) {
    this->licencia = licencia;
}

int ClaseConductor::GetLicencia() const {
    return licencia;
}

void ClaseConductor::operator +(const ClaseFalta &falta){
    char placa[100];
    lfaltas[numFaltas].SetCodInf(falta.GetCodInf());
    lfaltas[numFaltas].SetFecha(falta.GetFecha());
    falta.GetPlaca(placa);
    lfaltas[numFaltas].SetPlaca(placa);
    numFaltas++;
}

void ClaseConductor::operator +(const ClaseInfraccion &infraccion){
    char gravedad[50];
    for(int i=0;i<numFaltas;i++){
        if(lfaltas[i].GetCodInf()==infraccion.GetCodigo()){
            infraccion.GetGravedad(gravedad);
            lfaltas[i].SetGravedad(gravedad);
            lfaltas[i].SetMulta(infraccion.GetMulta());
        }
    }
}

void ClaseConductor::operator ++(){
    for(int i=0;i<numFaltas;i++){
        montoTotal+=lfaltas[i].GetMulta();
    }
}

void ClaseConductor::operator *(int fecha){
    char gravedad[50];
    for(int i=0;i<numFaltas;i++){
        if(lfaltas[i].GetFecha()<fecha){
            lfaltas[i].GetGravedad(gravedad);
            if(strcmp(gravedad,"Leve")==0){
                lfaltas[i].SetMulta(lfaltas[i].GetMulta()*0.50);
            }
            if(strcmp(gravedad,"Grave")==0){
                lfaltas[i].SetMulta(lfaltas[i].GetMulta()*0.75);
            }
            if(strcmp(gravedad,"Muy Grave")==0){
                lfaltas[i].SetMulta(lfaltas[i].GetMulta()*0.90);
            }
        }
    }
}