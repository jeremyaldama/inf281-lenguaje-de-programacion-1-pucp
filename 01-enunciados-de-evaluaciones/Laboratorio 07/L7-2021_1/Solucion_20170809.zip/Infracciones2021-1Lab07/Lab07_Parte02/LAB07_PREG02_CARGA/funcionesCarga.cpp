/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   funcionesCarga.cpp
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 18 de junio de 2021, 10:49 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
using namespace std;
#include "ClaseConductor.h"
#include "ClaseFalta.h"
#include "ClaseFaltaCond.h"
#include "ClaseInfraccion.h"
#include "funciones.h"
#include "funcionesCarga.h"
#include "sobrecarga.h"
#define MAX_LINEA 200

void leerConductores(ClaseConductor *conductor,int &numConductores){
    ifstream archConductores("Conductores.csv",ios::in);
    if(!archConductores){
        cout<<"ERROR: NO se puede abrir el archivo Conductores.csv"<<endl;
        exit(1);
    }
    
    while(1){
        archConductores>>conductor[numConductores];
        if(archConductores.eof()) break;
        numConductores++;
    }
    
}

void leerYAsignarFaltas(ClaseConductor *conductor,int numConductores){
    ifstream archRegistroDeFaltas("RegistroDeFaltas.csv",ios::in);
    if(!archRegistroDeFaltas){
        cout<<"ERROR: NO se puede abrir el archivo Conductores.csv"<<endl;
        exit(1);
    }
    
    ClaseFalta falta;
    
    while(1){
        archRegistroDeFaltas>>falta;
        if(archRegistroDeFaltas.eof()) break;
        
        for(int i=0;i<numConductores;i++){
            if(falta.GetLicencia()==conductor[i].GetLicencia()){
                conductor[i]+falta;
                break;
            }
        }
    }
}

void leerYCompletarInfracciones(ClaseConductor *conductor,int numConductores){
    ifstream archInfracciones("Infracciones.csv",ios::in);
    if(!archInfracciones){
        cout<<"ERROR: NO se puede abrir el archivo Conductores.csv"<<endl;
        exit(1);
    }
    
    ClaseInfraccion infraccion;
    
    while(1){
        archInfracciones>>infraccion;
        if(archInfracciones.eof()) break;
        
        for(int i=0;i<numConductores;i++){
            conductor[i]+infraccion;
        }
    }
}

void calcularMonto(ClaseConductor *conductor,int numConductores){
    for(int i=0;i<numConductores;i++){
        ++conductor[i];
    }
}

void emitirReporte(ClaseConductor *conductor,int numConductores){
    ofstream archReporte("Reporte.txt",ios::out);
    if(!archReporte){
        cout<<"ERROR: NO se puede abrir el archivo Reporte.txt"<<endl;
        exit(1);
    }
    
    for(int i=0;i<numConductores;i++){
        archReporte<<conductor[i];
    }
}

void aplicarAmnistia(ClaseConductor *conductor,int numConductores){
    int dd,mm,aa,fecha;
    char car;
    cout<<"Ingrese una fecha (dd/mm/aaaa): ";
    cin>>dd>>car>>mm>>car>>aa;
    fecha=aa*10000+mm*100+dd;
    for(int i=0;i<numConductores;i++){
        conductor[i]*fecha;
        ++conductor[i];
    }
    
}

void emitirReporteConAministia(ClaseConductor *conductor,int numConductores){
    ofstream archReporte("ReporteConAmnistia.txt",ios::out);
    if(!archReporte){
        cout<<"ERROR: NO se puede abrir el archivo ReporteConAmnistia.txt"<<endl;
        exit(1);
    }
    
    for(int i=0;i<numConductores;i++){
        archReporte<<conductor[i];
    }
}