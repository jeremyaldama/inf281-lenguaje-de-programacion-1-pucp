/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 18 de junio de 2021, 10:34 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
using namespace std;
#include "ClaseConductor.h"
#include "ClaseFalta.h"
#include "ClaseFaltaCond.h"
#include "ClaseInfraccion.h"
#include "sobrecarga.h"
#include "funciones.h"
#include "funcionesCarga.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    ClaseConductor conductor[200];
    int numConductores=0;
    
    leerConductores(conductor,numConductores);
    leerYAsignarFaltas(conductor,numConductores);
    leerYCompletarInfracciones(conductor,numConductores);
    calcularMonto(conductor,numConductores);
    emitirReporte(conductor,numConductores);
    aplicarAmnistia(conductor,numConductores);
    emitirReporteConAministia(conductor,numConductores);

    return 0;
}

