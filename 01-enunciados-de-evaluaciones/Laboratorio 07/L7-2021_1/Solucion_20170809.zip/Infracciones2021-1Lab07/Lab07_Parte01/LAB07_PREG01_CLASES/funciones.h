/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   funciones.h
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 18 de junio de 2021, 09:05 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H
#include <fstream>
using namespace std;

void imprimirLinea(char c,int cant,ofstream &);
void convertirFecha(int &dd,int &mm,int &aa,int fecha);


#endif /* FUNCIONES_H */

