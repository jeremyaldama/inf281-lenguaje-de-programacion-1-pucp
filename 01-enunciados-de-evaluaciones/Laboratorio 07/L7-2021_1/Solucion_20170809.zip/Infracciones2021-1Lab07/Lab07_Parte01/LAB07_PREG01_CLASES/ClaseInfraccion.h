/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ClaseInfraccion.h
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 18 de junio de 2021, 08:06 AM
 */

#ifndef CLASEINFRACCION_H
#define CLASEINFRACCION_H

class ClaseInfraccion {
private:
    int codigo;
    char *descripcion;
    char *gravedad;
    double multa;

public:
    ClaseInfraccion();
    ClaseInfraccion(const ClaseInfraccion& orig);
    virtual ~ClaseInfraccion();
    void SetMulta(double multa);
    double GetMulta() const;
    void SetGravedad(char* gravedad);
    void GetGravedad(char*) const;
    void SetDescripcion(char* descripcion);
    void GetDescripcion(char*) const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
};

#endif /* CLASEINFRACCION_H */

