/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   funciones.cpp
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 18 de junio de 2021, 09:05 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
using namespace std;
#include "ClaseConductor.h"
#include "ClaseFalta.h"
#include "ClaseFaltaCond.h"
#include "ClaseInfraccion.h"
#include "sobrecarga.h"
#define MAX_LINEA 200

void imprimirLinea(char car,int cant,ofstream &arch){
    for(int i=0;i<cant;i++){
        arch<<car;
    }
    arch<<endl;
}

void convertirFecha(int &dd,int &mm,int &aa,int fecha){
    aa=fecha/10000;
    fecha/=10000;
    mm=fecha/100;
    dd=fecha%100;
}