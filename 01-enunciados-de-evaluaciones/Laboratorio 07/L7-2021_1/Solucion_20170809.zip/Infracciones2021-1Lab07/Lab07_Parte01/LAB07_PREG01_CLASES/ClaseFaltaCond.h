/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ClaseFaltaCond.h
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 18 de junio de 2021, 08:06 AM
 */

#ifndef CLASEFALTACOND_H
#define CLASEFALTACOND_H

class ClaseFaltaCond {
private:
    char *placa;
    int fecha;
    int codInf;
    double multa;
    char *gravedad;

public:
    ClaseFaltaCond();
    ClaseFaltaCond(const ClaseFaltaCond& orig);
    virtual ~ClaseFaltaCond();
    
    void operator =(const ClaseFaltaCond &);
    void SetGravedad(char* gravedad);
    void GetGravedad(char*) const;
    void SetMulta(double multa);
    double GetMulta() const;
    void SetCodInf(int codInf);
    int GetCodInf() const;
    void SetFecha(int fecha);
    int GetFecha() const;
    void SetPlaca(char* placa);
    void GetPlaca(char*) const;
};

#endif /* CLASEFALTACOND_H */

