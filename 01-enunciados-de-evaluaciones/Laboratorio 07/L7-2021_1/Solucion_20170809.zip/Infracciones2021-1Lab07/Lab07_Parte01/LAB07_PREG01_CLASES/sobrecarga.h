/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   sobrecarga.h
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 18 de junio de 2021, 08:32 AM
 */

#ifndef SOBRECARGA_H
#define SOBRECARGA_H
#include <fstream>
using namespace std;
#include "ClaseConductor.h"
#include "ClaseFalta.h"
#include "ClaseInfraccion.h"

ifstream & operator >>(ifstream &in, ClaseConductor &conductor);
ifstream & operator >>(ifstream &in, ClaseFalta &falta);
ifstream & operator >>(ifstream &in, ClaseInfraccion &infraccion);
ofstream & operator <<(ofstream &out,const ClaseConductor &conductor);

#endif /* SOBRECARGA_H */

