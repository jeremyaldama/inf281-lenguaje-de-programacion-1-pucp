/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ClaseFalta.h
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 18 de junio de 2021, 08:06 AM
 */

#ifndef CLASEFALTA_H
#define CLASEFALTA_H

class ClaseFalta {
private:
    int licencia;
    char *placa;
    int codInf;
    int fecha;

public:
    ClaseFalta();
    ClaseFalta(const ClaseFalta& orig);
    virtual ~ClaseFalta();
    void SetFecha(int fecha);
    int GetFecha() const;
    void SetCodInf(int codInf);
    int GetCodInf() const;
    void SetPlaca(char* placa);
    void GetPlaca(char*) const;
    void SetLicencia(int licencia);
    int GetLicencia() const;
    
};

#endif /* CLASEFALTA_H */

