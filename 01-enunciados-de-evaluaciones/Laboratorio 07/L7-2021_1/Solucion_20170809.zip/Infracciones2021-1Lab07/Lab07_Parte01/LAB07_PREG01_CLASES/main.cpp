/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 18 de junio de 2021, 08:04 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
using namespace std;
#include "ClaseConductor.h"
#include "ClaseFalta.h"
#include "ClaseFaltaCond.h"
#include "ClaseInfraccion.h"
#include "sobrecarga.h"
#include "funciones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    ifstream archConductores("Conductores.csv",ios::in);
    if(!archConductores){
        cout<<"ERROR: NO se puede abrir el archivo Conductores.csv"<<endl;
        exit(1);
    }
    
    ifstream archInfracciones("Infracciones.csv",ios::in);
    if(!archInfracciones){
        cout<<"ERROR: NO se puede abrir el archivo Conductores.csv"<<endl;
        exit(1);
    }
    
    ifstream archRegistroDeFaltas("RegistroDeFaltas.csv",ios::in);
    if(!archRegistroDeFaltas){
        cout<<"ERROR: NO se puede abrir el archivo Conductores.csv"<<endl;
        exit(1);
    }
    
    ofstream archReporte("Reporte.txt",ios::out);
    if(!archReporte){
        cout<<"ERROR: NO se puede abrir el archivo Reporte.txt"<<endl;
        exit(1);
    }
    
    ClaseConductor conductor;
    ClaseFalta falta;
    ClaseInfraccion infraccion;
    int fecha=20211010;
    
    archConductores>>conductor;
    archRegistroDeFaltas>>falta;
    archInfracciones>>infraccion;
    
    //Como es unicamente prueba asumiremos que la falta leida pertenece al primer conductor leido
    conductor+falta;
    conductor+infraccion;
    ++conductor;
    conductor*fecha;
    
    archReporte<<conductor;

    return 0;
}

