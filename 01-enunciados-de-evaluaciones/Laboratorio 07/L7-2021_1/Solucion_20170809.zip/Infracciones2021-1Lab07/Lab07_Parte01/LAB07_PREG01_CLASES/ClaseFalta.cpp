/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ClaseFalta.cpp
 * Author: Alonso
 * 
 * Created on 18 de junio de 2021, 08:06 AM
 */

#include <cstring>
#include "ClaseFalta.h"

ClaseFalta::ClaseFalta() {
    placa=nullptr;
}

ClaseFalta::ClaseFalta(const ClaseFalta& orig) {
}

ClaseFalta::~ClaseFalta() {
}

void ClaseFalta::SetFecha(int fecha) {
    this->fecha = fecha;
}

int ClaseFalta::GetFecha() const {
    return fecha;
}

void ClaseFalta::SetCodInf(int codInf) {
    this->codInf = codInf;
}

int ClaseFalta::GetCodInf() const {
    return codInf;
}

void ClaseFalta::SetPlaca(char* aux) {
    if(placa!=nullptr) delete placa;
    placa=new char[strlen(aux)+1];
    strcpy(placa,aux);
}

void ClaseFalta::GetPlaca(char *aux) const {
    if(placa==nullptr) aux[0]=0;
    strcpy(aux,placa);
}

void ClaseFalta::SetLicencia(int licencia) {
    this->licencia = licencia;
}

int ClaseFalta::GetLicencia() const {
    return licencia;
}

