/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ClaseConductor.h
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 18 de junio de 2021, 08:05 AM
 */

#ifndef CLASECONDUCTOR_H
#define CLASECONDUCTOR_H
#include "ClaseFaltaCond.h"
#include "ClaseInfraccion.h"
#include "ClaseFalta.h"
#include "ClaseInfraccion.h"

class ClaseConductor {
private:
    int licencia;
    char *nombre;
    ClaseFaltaCond lfaltas[100];
    int numFaltas;
    double montoTotal;

public:
    ClaseConductor();
    ClaseConductor(const ClaseConductor& orig);
    virtual ~ClaseConductor();
    void SetMontoTotal(double montoTotal);
    double GetMontoTotal() const;
    void SetNumFaltas(int numFaltas);
    int GetNumFaltas() const;
    void SetLfaltas(const ClaseFaltaCond &);
    void GetLFaltas(ClaseFaltaCond &, int ) const;
    void SetNombre(char* aux);
    void GetNombre(char *aux) const;
    void SetLicencia(int licencia);
    int GetLicencia() const;
    
    void operator +(const ClaseFalta &falta);
    void operator +(const ClaseInfraccion &infraccion);
    void operator ++();
    void operator *(int fecha);
};

#endif /* CLASECONDUCTOR_H */

