/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ClaseFaltaCond.cpp
 * Author: Alonso
 * 
 * Created on 18 de junio de 2021, 08:06 AM
 */

#include <cstring>
#include "ClaseFaltaCond.h"

ClaseFaltaCond::ClaseFaltaCond() {
    placa=nullptr;
    gravedad=nullptr;
}

ClaseFaltaCond::ClaseFaltaCond(const ClaseFaltaCond& orig) {
}

ClaseFaltaCond::~ClaseFaltaCond() {
}

void ClaseFaltaCond::operator =(const ClaseFaltaCond &falta){
    fecha=falta.fecha;
    codInf=falta.codInf;
    multa=falta.multa;
    placa=new char[strlen(falta.placa)+1];
    strcpy(placa,falta.placa);
    gravedad=new char[strlen(falta.gravedad)+1];
    strcpy(gravedad,falta.gravedad);
}

void ClaseFaltaCond::SetGravedad(char* aux) {
    if(gravedad!=nullptr) delete gravedad;
    gravedad=new char[strlen(aux)+1];
    strcpy(gravedad,aux);
}

void ClaseFaltaCond::GetGravedad(char *aux) const {
    if(gravedad==nullptr) aux[0]=0;
    strcpy(aux,gravedad);
}

void ClaseFaltaCond::SetMulta(double multa) {
    this->multa = multa;
}

double ClaseFaltaCond::GetMulta() const {
    return multa;
}

void ClaseFaltaCond::SetCodInf(int codInf) {
    this->codInf = codInf;
}

int ClaseFaltaCond::GetCodInf() const {
    return codInf;
}

void ClaseFaltaCond::SetFecha(int fecha) {
    this->fecha = fecha;
}

int ClaseFaltaCond::GetFecha() const {
    return fecha;
}

void ClaseFaltaCond::SetPlaca(char* aux) {
    if(placa!=nullptr) delete placa;
    placa=new char[strlen(aux)+1];
    strcpy(placa,aux);
}

void ClaseFaltaCond::GetPlaca(char *aux) const {
    if(placa==nullptr) aux[0]=0;
    strcpy(aux,placa);
}