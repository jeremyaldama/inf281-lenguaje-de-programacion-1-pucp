/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ClaseInfraccion.cpp
 * Author: Alonso
 * 
 * Created on 18 de junio de 2021, 08:06 AM
 */

#include <cstring>
#include "ClaseInfraccion.h"

ClaseInfraccion::ClaseInfraccion() {
    descripcion=nullptr;
    gravedad=nullptr;
}

ClaseInfraccion::ClaseInfraccion(const ClaseInfraccion& orig) {
}

ClaseInfraccion::~ClaseInfraccion() {
}

void ClaseInfraccion::SetMulta(double multa) {
    this->multa = multa;
}

double ClaseInfraccion::GetMulta() const {
    return multa;
}

void ClaseInfraccion::SetGravedad(char* aux) {
    if(gravedad!=nullptr) delete gravedad;
    gravedad=new char[strlen(aux)+1];
    strcpy(gravedad,aux);
}

void ClaseInfraccion::GetGravedad(char *aux) const {
    if(gravedad==nullptr) aux[0]=0;
    strcpy(aux,gravedad);
}

void ClaseInfraccion::SetDescripcion(char* aux) {
    if(descripcion!=nullptr) delete descripcion;
    descripcion=new char[strlen(aux)+1];
    strcpy(descripcion,aux);
}


void ClaseInfraccion::GetDescripcion(char* aux) const {
    if(descripcion==nullptr) aux[0]=0;
    strcpy(aux,descripcion);
}


void ClaseInfraccion::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int ClaseInfraccion::GetCodigo() const {
    return codigo;
}

