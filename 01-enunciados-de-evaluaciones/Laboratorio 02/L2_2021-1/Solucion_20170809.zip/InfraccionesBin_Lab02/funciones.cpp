/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * Nombre: Alonso Oswaldo Acosta Gonzales
 * Codigo Alumno : 20170809
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
#include "funciones.h"
#include <string.h>

void crearConductresBin(){
    fstream archConductoresBin("Conductores.bin",ios::out|ios::binary);
    if(!archConductoresBin){
        cout<<"ERROR: No se puede abrir el archivo Conductores.bin"<<endl;
        exit(1);
    }
    ifstream archInfConductores("Infracciones-Conductores.txt",ios::in);
    if(!archInfConductores){
        cout<<"ERROR: No se pudo abrir el archivo Infracciones-Conductores.txt"<<endl;
        exit(1);
    }
    
    int licConductor,dd,mm,aa,codInfraccion,aux,numFaltasLeves=0,numFaltasGraves=0,numFaltasMuyGraves=0;
    char nombre[100],placa[20],tipoInfraccion,car;
    double montoFaltasLeves=0.0,montoFaltasGraves=0.0,montoFaltasMuyGraves=0.0,totalMonto=0.0;
    
    archInfConductores>>licConductor;
    if(archInfConductores.eof()) return;
    while(1){
        archInfConductores>>nombre;
        if(archInfConductores.eof()) break;
        
        archConductoresBin.write(reinterpret_cast<const char*> (&licConductor),sizeof(int));
        archConductoresBin.write(reinterpret_cast<const char*> (nombre),sizeof(char)*100);
        archConductoresBin.write(reinterpret_cast<const char*> (&numFaltasLeves),sizeof(int));
        archConductoresBin.write(reinterpret_cast<const char*> (&numFaltasGraves),sizeof(int));
        archConductoresBin.write(reinterpret_cast<const char*> (&numFaltasMuyGraves),sizeof(int));
        archConductoresBin.write(reinterpret_cast<const char*> (&montoFaltasLeves),sizeof(double));
        archConductoresBin.write(reinterpret_cast<const char*> (&montoFaltasGraves),sizeof(double));
        archConductoresBin.write(reinterpret_cast<const char*> (&montoFaltasMuyGraves),sizeof(double));
        archConductoresBin.write(reinterpret_cast<const char*> (&totalMonto),sizeof(double));
        
        //Leemos el resto del archivo
        while(1){
            archInfConductores>>placa>>dd>>car>>mm>>car>>aa>>tipoInfraccion>>codInfraccion;
            
            aux=licConductor;
            archInfConductores>>licConductor;
            if(archInfConductores.eof()) break;
            if(archInfConductores.fail()){ //Si falla leyó un placa de auto
                archInfConductores.clear();
                licConductor=aux;
            }
            else{ //Si no falla, estamos en otra linea
                break;
            }
        }
    }
    
}

void crearFaltasCometidasBin(){
    
    fstream archFaltasCometidasBin("FaltasCometidas.bin",ios::out|ios::binary);
    if(!archFaltasCometidasBin){
        cout<<"ERROR: No se puede abrir el archivo FaltasCometidas.bin"<<endl;
        exit(1);
    }
    ifstream archInfConductores("Infracciones-Conductores.txt",ios::in);
    if(!archInfConductores){
        cout<<"ERROR: No se pudo abrir el archivo Infracciones-Conductores.txt"<<endl;
        exit(1);
    }
    
    int licConductor,dd,mm,aa,codInfraccion,aux,fecha;
    char nombre[100],placa[20],tipoInfraccion,leve[20]="LEVE",grave[20]="GRAVE",muyGrave[20]="MUY GRAVE",car;
    double monto=0.0;
    
    archInfConductores>>licConductor;
    if(archInfConductores.eof()) return;
    while(1){
        archInfConductores>>nombre;
        if(archInfConductores.eof()) break;
        
        //Leemos el resto del archivo
        while(1){
            archInfConductores>>placa>>dd>>car>>mm>>car>>aa>>tipoInfraccion>>codInfraccion;
            fecha=aa*10000+mm*100+dd;
            
            archFaltasCometidasBin.write(reinterpret_cast<const char*> (placa),sizeof(char)*20);
            archFaltasCometidasBin.write(reinterpret_cast<const char*> (&licConductor),sizeof(int));
            archFaltasCometidasBin.write(reinterpret_cast<const char*> (&fecha),sizeof(int));
            if(tipoInfraccion=='L')
                archFaltasCometidasBin.write(reinterpret_cast<const char*> (leve),sizeof(char)*20);
            else if(tipoInfraccion=='G')
                archFaltasCometidasBin.write(reinterpret_cast<const char*> (grave),sizeof(char)*20);
            else if(tipoInfraccion=='M')
                archFaltasCometidasBin.write(reinterpret_cast<const char*> (muyGrave),sizeof(char)*20);
            archFaltasCometidasBin.write(reinterpret_cast<const char*> (&codInfraccion),sizeof(int));
            archFaltasCometidasBin.write(reinterpret_cast<const char*> (&monto),sizeof(double));
            
            aux=licConductor;
            archInfConductores>>licConductor;
            if(archInfConductores.eof()) break;
            if(archInfConductores.fail()){ //Si falla leyó un placa de auto
                archInfConductores.clear();
                licConductor=aux;
            }
            else{ //Si no falla, estamos en otra linea
                break;
            }
        }
    }   
}

void mostrarConductoresBin(){
    fstream archConductoresBin("Conductores.bin",ios::in|ios::binary);
    if(!archConductoresBin){
        cout<<"ERROR: No se puede abrir el archivo Conductores.bin"<<endl;
        exit(1);
    }
    ofstream archConductoresMuestra("ConductoresMuestra.txt",ios::out);
    if(!archConductoresMuestra){
        cout<<"ERROR: No se puede abrir el archivo ConductoresMuestra.txt"<<endl;
        exit(1);
    }
    
    int licConductor,dd,mm,aa,codInfraccion,aux,numFaltasLeves,numFaltasGraves,numFaltasMuyGraves;
    char nombre[100],placa[20],tipoInfraccion;
    double montoFaltasLeves,montoFaltasGraves,montoFaltasMuyGraves,totalMonto;
    
    archConductoresMuestra.precision(2);
    archConductoresMuestra<<fixed;
    
    while(1){
        archConductoresBin.read(reinterpret_cast<char*> (&licConductor),sizeof(int));
        if(archConductoresBin.eof()) break;
        archConductoresBin.read(reinterpret_cast<char*> (nombre),sizeof(char)*100);
        archConductoresBin.read(reinterpret_cast<char*> (&numFaltasLeves),sizeof(int));
        archConductoresBin.read(reinterpret_cast<char*> (&numFaltasGraves),sizeof(int));
        archConductoresBin.read(reinterpret_cast<char*> (&numFaltasMuyGraves),sizeof(int));
        archConductoresBin.read(reinterpret_cast<char*> (&montoFaltasLeves),sizeof(double));
        archConductoresBin.read(reinterpret_cast<char*> (&montoFaltasGraves),sizeof(double));
        archConductoresBin.read(reinterpret_cast<char*> (&montoFaltasMuyGraves),sizeof(double));
        archConductoresBin.read(reinterpret_cast<char*> (&totalMonto),sizeof(double));
        
        archConductoresMuestra<<licConductor<<setw(5)<<" "<<left<<setw(40)<<nombre<<right<<setw(10)<<numFaltasLeves<<setw(10)<<numFaltasGraves<<setw(10)<<numFaltasMuyGraves
                <<setw(10)<<montoFaltasLeves<<setw(10)<<montoFaltasGraves<<setw(10)<<montoFaltasMuyGraves<<setw(10)<<totalMonto<<endl;    
    }
    
}


void mostarFaltasCometidasBin(){
    fstream archFaltasCometidasBin("FaltasCometidas.bin",ios::in|ios::binary);
    if(!archFaltasCometidasBin){
        cout<<"ERROR: No se puede abrir el archivo FaltasCometidas.bin"<<endl;
        exit(1);
    }
    ofstream archFaltasMuestra("FaltasCometidasMuestra.txt",ios::out);
    if(!archFaltasMuestra){
        cout<<"ERROR: No se puede abrir el archivo FaltasCometidasMuestra.txt"<<endl;
        exit(1);
    }
    
    int licConductor,dd,mm,aa,codInfraccion,aux,fecha;
    char nombre[100],placa[20],tipoInfraccion,car,gravedadInfraccion[20];
    double monto=0.0;
    
    archFaltasMuestra.precision(2);
    archFaltasMuestra<<fixed;
    
    while(1){
        archFaltasCometidasBin.read(reinterpret_cast<char*> (placa),sizeof(char)*20);
        if(archFaltasCometidasBin.eof()) break;
        archFaltasCometidasBin.read(reinterpret_cast<char*> (&licConductor),sizeof(int));
        archFaltasCometidasBin.read(reinterpret_cast<char*> (&fecha),sizeof(int));
        archFaltasCometidasBin.read(reinterpret_cast<char*> (gravedadInfraccion),sizeof(char)*20);
        archFaltasCometidasBin.read(reinterpret_cast<char*> (&codInfraccion),sizeof(int));
        archFaltasCometidasBin.read(reinterpret_cast<char*> (&monto),sizeof(double));
        
        aa=fecha/10000;
        fecha%=10000;
        mm=fecha/100;
        dd=fecha%100;
        
        archFaltasMuestra<<placa<<setw(15)<<licConductor<<setw(5)<<" "<<setfill('0')<<setw(2)<<dd<<"/"<<setw(2)<<mm<<"/"<<setw(4)<<aa<<setfill(' ')<<setw(5)<<" "
                <<left<<setw(15)<<gravedadInfraccion<<right<<setw(10)<<codInfraccion<<setw(10)<<monto<<endl;
        
    }
    
}

void crearListadoInfraccionesBin(){
    fstream archListadoInfraccionesBin("ListadoDeInfracciones.bin",ios::out|ios::binary);
    if(!archListadoInfraccionesBin){
        cout<<"ERROR: No se puede abrir el archivo ListadoDeInfracciones.bin"<<endl;
        exit(1);
    }
    ifstream archInfracciones("Infracciones.txt",ios::in);
    if(!archInfracciones){
        cout<<"ERROR: No se puede abrir el archivo Infracciones.txt"<<endl;
        exit(1);
    }
    int codInfraccion;
    char descripcion[250],gravedad[20];
    double multa;
    
    while(1){
        archInfracciones>>codInfraccion;
        if(archInfracciones.eof()) break;
        archInfracciones>>descripcion>>gravedad>>multa;
        
        archListadoInfraccionesBin.write(reinterpret_cast<const char*> (&codInfraccion),sizeof(int));
        archListadoInfraccionesBin.write(reinterpret_cast<const char*> (descripcion),sizeof(char)*250);
        archListadoInfraccionesBin.write(reinterpret_cast<const char*> (gravedad),sizeof(char)*20);
        archListadoInfraccionesBin.write(reinterpret_cast<const char*> (&multa),sizeof(double));
    }
}

void mostrarListadoInfraccionesBin(){
    fstream archListadoInfraccionesBin("ListadoDeInfracciones.bin",ios::in|ios::binary);
    if(!archListadoInfraccionesBin){
        cout<<"ERROR: No se puede abrir el archivo ListadoDeInfracciones.bin"<<endl;
        exit(1);
    }
    ofstream archInfraccionesMuestra("ListadoDeInfraccionesMuestra.txt",ios::out);
    if(!archInfraccionesMuestra){
        cout<<"ERROR: No se puede abrir el archivo ListadoDeInfraccionesMuestra.txt"<<endl;
        exit(1);
    }
    
    int codInfraccion;
    char descripcion[250],gravedad[20];
    double multa;
    
    archInfraccionesMuestra.precision(2);
    archInfraccionesMuestra<<fixed;
    
    while(1){
        archListadoInfraccionesBin.read(reinterpret_cast<char*> (&codInfraccion),sizeof(int));
        if(archListadoInfraccionesBin.eof()) break;
        archListadoInfraccionesBin.read(reinterpret_cast<char*> (descripcion),sizeof(char)*250);
        archListadoInfraccionesBin.read(reinterpret_cast<char*> (gravedad),sizeof(char)*20);
        archListadoInfraccionesBin.read(reinterpret_cast<char*> (&multa),sizeof(double));
        
        archInfraccionesMuestra<<codInfraccion<<setw(5)<<" "<<left<<setw(200)<<descripcion<<setw(5)<<" "<<setw(15)<<gravedad<<right<<setw(5)<<" "<<multa<<endl;
    }
    
}

void actualizarArchivos(){
    fstream archConductoresBin("Conductores.bin",ios::in|ios::out|ios::binary);
    if(!archConductoresBin){
        cout<<"ERROR: No se puede abrir el archivo Conductores.bin"<<endl;
        exit(1);
    }
    fstream archFaltasCometidasBin("FaltasCometidas.bin",ios::in|ios::out|ios::binary);
    if(!archFaltasCometidasBin){
        cout<<"ERROR: No se puede abrir el archivo FaltasCometidas.bin"<<endl;
        exit(1);
    }
    fstream archListadoInfraccionesBin("ListadoDeInfracciones.bin",ios::in|ios::binary);
    if(!archListadoInfraccionesBin){
        cout<<"ERROR: No se puede abrir el archivo ListadoDeInfracciones.bin"<<endl;
        exit(1);
    }
    
    int licConductor,dd,mm,aa,codInfraccion,aux,fecha;
    char nombre[100],placa[20],tipoInfraccion,car,gravedadInfraccion[20];
    double monto=0.0;
    
    int tamArch,numReg,tamReg;
    archConductoresBin.seekg(0,ios::end);
    tamArch=archConductoresBin.tellg();
    tamReg=sizeof(int)*4+sizeof(char)*100+sizeof(double)*4;
    numReg=tamArch/tamReg;
    
    
    while(1){
        archFaltasCometidasBin.read(reinterpret_cast<char*> (placa),sizeof(char)*20);
        if(archFaltasCometidasBin.eof()) break;
        archFaltasCometidasBin.read(reinterpret_cast<char*> (&licConductor),sizeof(int));
        archFaltasCometidasBin.read(reinterpret_cast<char*> (&fecha),sizeof(int));
        archFaltasCometidasBin.read(reinterpret_cast<char*> (gravedadInfraccion),sizeof(char)*20);
        archFaltasCometidasBin.read(reinterpret_cast<char*> (&codInfraccion),sizeof(int));
        
        monto=obtenerMontoMulta(codInfraccion,archListadoInfraccionesBin);
        archFaltasCometidasBin.write(reinterpret_cast<char*> (&monto),sizeof(double));
        actualizarConductoresBin(licConductor,monto,gravedadInfraccion,archConductoresBin,tamArch,numReg,tamReg);
    }
}

double obtenerMontoMulta(int codInfraccion,fstream &archListadoInfraccionesBin){
    archListadoInfraccionesBin.seekg(0,ios::beg);
    
    int codInfraccionArch;
    char descripcion[250],gravedad[20];
    double multa;
    
    while(1){
        archListadoInfraccionesBin.read(reinterpret_cast<char*> (&codInfraccionArch),sizeof(int));
        if(archListadoInfraccionesBin.eof()) break;
        archListadoInfraccionesBin.read(reinterpret_cast<char*> (descripcion),sizeof(char)*250);
        archListadoInfraccionesBin.read(reinterpret_cast<char*> (gravedad),sizeof(char)*20);
        archListadoInfraccionesBin.read(reinterpret_cast<char*> (&multa),sizeof(double));
        
        if(codInfraccion==codInfraccionArch)
            return multa;
    }
    return 0;
}

void actualizarConductoresBin(int licConductor,double monto,char *gravedadInfraccion,fstream &archConductoresBin,int tamArch,int numReg,int tamReg){
    archConductoresBin.seekg(0,ios::beg);
    
    int licConductorArch,dd,mm,aa,codInfraccion,aux,numFaltasLeves,numFaltasGraves,numFaltasMuyGraves;
    char nombre[100],placa[20],tipoInfraccion;
    double montoFaltasLeves,montoFaltasGraves,montoFaltasMuyGraves,totalMonto;
    
    
    for(int i=0;i<numReg;i++){
        archConductoresBin.seekg(i*tamReg,ios::beg);
        archConductoresBin.read(reinterpret_cast<char*> (&licConductorArch),sizeof(int));
        archConductoresBin.read(reinterpret_cast<char*> (nombre),sizeof(char)*100);
        archConductoresBin.read(reinterpret_cast<char*> (&numFaltasLeves),sizeof(int));
        archConductoresBin.read(reinterpret_cast<char*> (&numFaltasGraves),sizeof(int));
        archConductoresBin.read(reinterpret_cast<char*> (&numFaltasMuyGraves),sizeof(int));
        archConductoresBin.read(reinterpret_cast<char*> (&montoFaltasLeves),sizeof(double));
        archConductoresBin.read(reinterpret_cast<char*> (&montoFaltasGraves),sizeof(double));
        archConductoresBin.read(reinterpret_cast<char*> (&montoFaltasMuyGraves),sizeof(double));
        archConductoresBin.read(reinterpret_cast<char*> (&totalMonto),sizeof(double));

        if(licConductor==licConductorArch){
            
            if(strcmp(gravedadInfraccion,"LEVE")==0){
                numFaltasLeves++;
                montoFaltasLeves+=monto;
            }
            else if(strcmp(gravedadInfraccion,"GRAVE")==0){
                numFaltasGraves++;
                montoFaltasGraves+=monto;
            }
            else if(strcmp(gravedadInfraccion,"MUY GRAVE")==0){
                numFaltasMuyGraves++;
                montoFaltasMuyGraves+=monto;
            }
            totalMonto+=monto;
            
            archConductoresBin.seekg(i*tamReg,ios::beg);
            archConductoresBin.seekg(sizeof(int)+sizeof(char)*100,ios::cur);
            
            archConductoresBin.write(reinterpret_cast<const char*> (&numFaltasLeves),sizeof(int));
            archConductoresBin.write(reinterpret_cast<const char*> (&numFaltasGraves),sizeof(int));
            archConductoresBin.write(reinterpret_cast<const char*> (&numFaltasMuyGraves),sizeof(int));
            archConductoresBin.write(reinterpret_cast<const char*> (&montoFaltasLeves),sizeof(double));
            archConductoresBin.write(reinterpret_cast<const char*> (&montoFaltasGraves),sizeof(double));
            archConductoresBin.write(reinterpret_cast<const char*> (&montoFaltasMuyGraves),sizeof(double));
            archConductoresBin.write(reinterpret_cast<const char*> (&totalMonto),sizeof(double));
            break;
        }
    }
}

void aplicarAmnistia(){
    int dd,mm,aa;
    char car;
    cout<<"Ingrese una fecha: ";
    cin>>dd>>car>>mm>>car>>aa;
    
    int fechaUsuario=aa*10000+mm*100+dd;
    
    fstream archFaltasCometidasBin("FaltasCometidas.bin",ios::in|ios::binary);
    if(!archFaltasCometidasBin){
        cout<<"ERROR: No se puede abrir el archivo FaltasCometidas.bin"<<endl;
        exit(1);
    }
    
    int licConductor,codInfraccion,aux,fecha;
    char nombre[100],placa[20],tipoInfraccion,gravedadInfraccion[20];
    double monto=0.0;
    
    
    while(1){
        archFaltasCometidasBin.read(reinterpret_cast<char*> (placa),sizeof(char)*20);
        if(archFaltasCometidasBin.eof()) break;
        archFaltasCometidasBin.read(reinterpret_cast<char*> (&licConductor),sizeof(int));
        archFaltasCometidasBin.read(reinterpret_cast<char*> (&fecha),sizeof(int));
        archFaltasCometidasBin.read(reinterpret_cast<char*> (gravedadInfraccion),sizeof(char)*20);
        archFaltasCometidasBin.read(reinterpret_cast<char*> (&codInfraccion),sizeof(int));
        archFaltasCometidasBin.read(reinterpret_cast<char*> (&monto),sizeof(double));
        
        if(fecha<=fechaUsuario){
            if(strcmp(gravedadInfraccion,"LEVE")==0){
                monto=0;
            }
            else if(strcmp(gravedadInfraccion,"GRAVE")==0){
                monto*=0.75;
            }
            else if(strcmp(gravedadInfraccion,"MUY GRAVE")==0){
                monto*=0.92;
            }
        }
        
        actualizarFaltasCometidasBin();
    }
        
}

void actualizarFaltasCometidasBin(){
    
}