/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   funciones.h
 * Author: Alonso
 *
 * Created on 23 de abril de 2021, 08:13 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H
#include <fstream>
using namespace std;

void crearConductresBin();
void crearFaltasCometidasBin();
void mostrarConductoresBin();
void mostarFaltasCometidasBin();
void crearListadoInfraccionesBin();
void mostrarListadoInfraccionesBin();
void actualizarArchivos();
double obtenerMontoMulta(int ,fstream &);
void actualizarConductoresBin(int ,double ,char *,fstream &,int ,int ,int );
void aplicarAmnistia();
void actualizarFaltasCometidasBin();

#endif /* FUNCIONES_H */

