/* 
 * Proyecto: LAB08_PREG02
 * File:   Pedido.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 17 de junio de 2022, 8:13
 */

#ifndef PEDIDO_H
#define PEDIDO_H

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "Producto.h"

class Pedido : public Producto {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    
    void SetObs(const char *cad);
    void GetObs(char *cad) const;
    void SetTotal(double total);
    double GetTotal() const;
    void SetFecha(int fecha);
    int GetFecha() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    
    void cargapedido(int cod, int cant, int d, int f, double t, char *o);
    
    void leerpedido(ifstream & arch);
    void buscaproducto(int codProd, char *descripcion, double &precio, int &stock);
    
    void imprimirpedido(ofstream &arch);
    void imprimirfecha(ofstream &arch);
    
    void actualizapedido(char catCliente);
private:
    int codigo; // cod del prod
    int cantidad;
    int dni;
    int fecha;
    double total;
    char *obs;
};

#endif /* PEDIDO_H */

