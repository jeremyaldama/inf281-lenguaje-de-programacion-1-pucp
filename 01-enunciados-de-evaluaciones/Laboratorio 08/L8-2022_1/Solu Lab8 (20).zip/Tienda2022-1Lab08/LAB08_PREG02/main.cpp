/* 
 * Proyecto: LAB08_PREG02
 * File:   main.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 17 de junio de 2022, 8:05
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>
using namespace std;

#include "Tienda.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    Tienda tien;
    
    tien.carga();
    tien.actualiza(20);
    tien.muestra();
    
    return 0;
}

