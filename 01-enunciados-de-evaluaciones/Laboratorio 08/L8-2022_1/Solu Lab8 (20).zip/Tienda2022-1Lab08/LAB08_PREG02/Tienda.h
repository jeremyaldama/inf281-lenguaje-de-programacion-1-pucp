/* 
 * Proyecto: LAB08_PREG02
 * File:   Tienda.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 17 de junio de 2022, 8:19
 */

#ifndef TIENDA_H
#define TIENDA_H

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "Pedido.h"
#include "Cliente.h"

class Tienda {
public:
    Tienda();
    Tienda(const Tienda& orig);
    virtual ~Tienda();
    
    void carga();
    void cargapedidos();
    void cargaclientes();
    void imprimirclientes(); // metodo adicional de verificacion
    
    void actualiza(int cantMax);
    char buscarcliente(int dni);
    
    void muestra();
private:
    Pedido lpedidos[200];
    Cliente lclientes[100];
};

#endif /* TIENDA_H */

