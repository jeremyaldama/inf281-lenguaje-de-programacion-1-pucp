/* 
 * Proyecto: LAB08_PREG02
 * File:   Producto.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 17 de junio de 2022, 8:11
 */

#ifndef PRODUCTO_H
#define PRODUCTO_H

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

class Producto {
public:
    Producto();
    Producto(const Producto& orig);
    virtual ~Producto();
    
    void SetStock(int stock);
    int GetStock() const;
    void SetPrecio(double precio);
    double GetPrecio() const;
    void SetCodProd(int codProd);
    int GetCodProd() const;
    void SetDescripcion(const char *cad);
    void GetDescripcion(char *cad) const;
    
    void cargaproducto(int c, char *nom, double p, int s);
    
private:
    int codProd;
    char *nombre; // descripcion
    double precio;
    int stock;
};

#endif /* PRODUCTO_H */

