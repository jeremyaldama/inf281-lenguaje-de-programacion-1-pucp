/* 
 * Proyecto: LAB08_PREG02
 * File:   Tienda.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 17 de junio de 2022, 8:19
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Tienda.h"

Tienda::Tienda() {
}

Tienda::Tienda(const Tienda& orig) {
}

Tienda::~Tienda() {
}

// ---------------------------------------------------------------------------

void Tienda::carga() {
    cargapedidos();
    cargaclientes();
    imprimirclientes();
}

void Tienda::cargapedidos(){
    ifstream arch("pedidos3.csv",ios::in);
    if(!arch){
        cout << "No se puede abrir los pedidos3";
        exit(1);
    }
    
    int i=0;
    while(1){
        lpedidos[i].leerpedido(arch);
        if(arch.eof()) break;
        i++;
    }
}

void Tienda::cargaclientes() {
    ifstream arch("clientes2.csv",ios::in);
    if(!arch){
        cout << "No se puede abrir los clientes2";
        exit(1);
    }
    
    int i=0;
    while(1){
        lclientes[i].leercliente(arch);
        if(arch.eof()) break;
        i++;
    }
}

// metodo para poder verificar la carga de los clientes
void Tienda::imprimirclientes(){
    ofstream arch("reporteclientes.txt",ios::out);
    if(!arch){
        cout << "No se puede abrir los reporteclientes";
        exit(1);
    }
    
    for(int i=0; lclientes[i].GetDni(); i++){
        lclientes[i].imprimircliente(arch);
    }
}

// ---------------------------------------------------------------------------

void Tienda::actualiza(int cantMax) {
    char catCliente;
    int codProd;
    double porctPagar; // 1-descuento
    for(int i=0; lpedidos[i].GetCodigo(); i++){
        if(lpedidos[i].GetStock() >= cantMax){
            catCliente = buscarcliente(lpedidos[i].GetDni());
            codProd = lpedidos[i].GetCodProd();
            
            if(codProd/100000 == 4 && catCliente != 'X'){
                lpedidos[i].actualizapedido(catCliente);
            }
        }
    }
}

char Tienda::buscarcliente(int dni){
    for(int i=0; lclientes[i].GetDni(); i++){
        if(lclientes[i].GetDni() == dni){
            return lclientes[i].GetCategoria();
        }
    }
    return 'X';
}


// ---------------------------------------------------------------------------

void Tienda::muestra() {
    ofstream arch("reporte - con descuentos.txt",ios::out);
    if(!arch){
        cout << "No se puede abrir los reporte - con descuentos";
        exit(1);
    }
    arch << setprecision(2) << fixed;

    arch << left << setw(13) << "Fecha" << setw(9) << "Codigo" << setw(55) << "Descripcion del Prod" <<
            setw(10) << "Cant" << setw(10) << "Precio" << setw(10) << "Total" << "Observaciones" << endl;

    for (int l = 0; l < 150; l++) arch.put('=');
    arch << endl;
    
    for(int i=0; lpedidos[i].GetCodigo(); i++){
        lpedidos[i].imprimirpedido(arch);
    }
}

