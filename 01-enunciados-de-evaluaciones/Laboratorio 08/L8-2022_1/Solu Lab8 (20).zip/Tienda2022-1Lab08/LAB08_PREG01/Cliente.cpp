/* 
 * Proyecto: LAB08_PREG01
 * File:   Cliente.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 17 de junio de 2022, 8:06
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Cliente.h"

Cliente::Cliente() {
    inicializarCliente();
}

void Cliente::inicializarCliente(){
    dni = 0;
    nombre = nullptr;
}

Cliente::Cliente(const Cliente& orig) {
}

Cliente::~Cliente() {
    if(nombre != nullptr) delete nombre;
}

// ---------------------------------------------------------------------------

void Cliente::SetCategoria(char categoria) {
    this->categoria = categoria;
}

char Cliente::GetCategoria() const {
    return categoria;
}

void Cliente::SetDni(int dni) {
    this->dni = dni;
}

int Cliente::GetDni() const {
    return dni;
}

void Cliente::SetNombre(const char *cad) {
    if(nombre != nullptr) delete nombre;
    nombre = new char[strlen(cad) + 1];
    strcpy(nombre, cad);
}

void Cliente::GetNombre(char *cad) const {
    if (nombre == nullptr) cad[0] = 0; //Cadena vacía
    else strcpy(cad, nombre);
}

void Cliente::cargacliente(int d, char c, char *n){
    SetDni(d);
    SetCategoria(c);
    SetNombre(n);
}

// ---------------------------------------------------------------------------

void Cliente::leercliente(ifstream& arch) {
    int dniLeido;
    char nombreLeido[200], catLeida;
    
    arch >> dniLeido;
    if(arch.eof()) return;
    arch.get(); // coma
    
    arch.getline(nombreLeido, 200, ',');
    arch >> catLeida;
    
    cargacliente(dniLeido, catLeida, nombreLeido);
}

// ---------------------------------------------------------------------------

void Cliente::imprimircliente(ofstream& arch) {
    arch << left << setw(10) << GetDni() << setw(50) << nombre << setw(10) << GetCategoria() << endl;
}