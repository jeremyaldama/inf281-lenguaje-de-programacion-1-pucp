/* 
 * Proyecto: LAB08_PREG01
 * File:   Producto.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 17 de junio de 2022, 8:11
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Producto.h"

Producto::Producto() {
    codProd = 0;
    nombre = nullptr;
    precio = 0;
    stock = 0;
}

Producto::Producto(const Producto& orig) {
}

Producto::~Producto() {
    if(nombre != nullptr) delete nombre;
}

// ---------------------------------------------------------------------------

void Producto::SetStock(int stock) {
    this->stock = stock;
}

int Producto::GetStock() const {
    return stock;
}

void Producto::SetPrecio(double precio) {
    this->precio = precio;
}

double Producto::GetPrecio() const {
    return precio;
}

void Producto::SetCodProd(int codProd) {
    this->codProd = codProd;
}

int Producto::GetCodProd() const {
    return codProd;
}

void Producto::SetDescripcion(const char *cad) {
    if(nombre != nullptr) delete nombre;
    nombre = new char[strlen(cad) + 1];
    strcpy(nombre, cad);
}

void Producto::GetDescripcion(char *cad) const {
    if (nombre == nullptr) cad[0] = 0; //Cadena vacía
    else strcpy(cad, nombre);
}

void Producto::cargaproducto(int c, char *nom, double p, int s){
    SetCodProd(c);
    SetDescripcion(nom);
    SetPrecio(p);
    SetStock(s);
}

// ---------------------------------------------------------------------------