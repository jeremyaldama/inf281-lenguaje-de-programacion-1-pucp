/* 
 * Proyecto: LAB08_PREG01
 * File:   Pedido.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 17 de junio de 2022, 8:13
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Pedido.h"

Pedido::Pedido() {
    codigo = 0;
    cantidad = 0;
    dni = 0;
    fecha = 0;
    total = 0;
    obs = nullptr;
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
    if(obs != nullptr) delete obs;
}

// ---------------------------------------------------------------------------

void Pedido::SetObs(const char *cad) {
    if(obs != nullptr) delete obs;
    obs = new char[strlen(cad) + 1];
    strcpy(obs, cad);
}

void Pedido::GetObs(char *cad) const {
    if (obs == nullptr) cad[0] = 0; //Cadena vacía
    else strcpy(cad, obs);
}

void Pedido::SetTotal(double total) {
    this->total = total;
}

double Pedido::GetTotal() const {
    return total;
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetDni(int dni) {
    this->dni = dni;
}

int Pedido::GetDni() const {
    return dni;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}

void Pedido::cargapedido(int cod, int cant, int d, int f, double t, char *o){
    SetCodigo(cod);
    SetCantidad(cant);
    SetDni(d);
    SetFecha(f);
    SetTotal(t);
    SetObs(o);
}

// ---------------------------------------------------------------------------

void Pedido::leerpedido(ifstream& arch) {
    char c, descripcion[200];
    double precio;
    int dd, mm, aa, stock, codLeido;
    
    arch >> codLeido;
    if(arch.eof()) return;
    arch.get(); // coma
    
    SetCodigo(codLeido);
    
    buscaproducto(codLeido, descripcion, precio, stock);
    cargaproducto(codLeido, descripcion, precio, stock);
    
    arch >> cantidad >> c >> dni >> c >> dd >> c >> mm >> c >> aa;
    fecha = dd + mm *100 + aa *10000;
    total = precio*cantidad;
}

void Pedido::buscaproducto(int codProd, char *descripcion, double &precio, int &stock) {
    ifstream arch("productos3.csv",ios::in);
    if(!arch){
        cout << "No se pudo abrir el archivo productos3";
        exit(1);
    }
    
    int codLeido;
    char cadena[200], c ;
    double precUni;
    while(1){
        arch >> codLeido;
        if(arch.eof()) break;
        arch.get(); // coma
        arch.getline(descripcion, 200, ',');
        arch >> precio >> c >> stock;
        if(codLeido == codProd) return;
    }
}

// ---------------------------------------------------------------------------

void Pedido::imprimirpedido(ofstream &arch){
    char descripcion[200], observaciones[200];
    
    imprimirfecha(arch);
    
    GetDescripcion(descripcion);
    GetObs(observaciones);
    arch << "   " << left << GetCodigo() << "   " << setw(50) << descripcion <<
            right << setw(10) << GetCantidad() << setw(10) << GetPrecio() <<
            setw(10) << GetTotal() << "  " << right << observaciones<<endl;
}

void Pedido::imprimirfecha(ofstream &arch){
    int fecha = GetFecha();
    
    int dd, mm, aa;
    dd = fecha%100;
    mm = (fecha/100)%100;
    aa = (fecha/100)/100;
    arch << right << setfill('0') << setw(2) << dd << "/" << 
            setw(2) << mm << "/" 
            << setw(4) << aa << setfill(' ');
}