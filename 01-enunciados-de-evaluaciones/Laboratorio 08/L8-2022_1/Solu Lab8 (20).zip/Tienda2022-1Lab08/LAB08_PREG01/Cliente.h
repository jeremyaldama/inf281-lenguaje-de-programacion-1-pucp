/* 
 * Proyecto: LAB08_PREG01
 * File:   Cliente.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 17 de junio de 2022, 8:06
 */

#ifndef CLIENTE_H
#define CLIENTE_H

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

class Cliente {
public:
    Cliente();
    void inicializarCliente();
    Cliente(const Cliente& orig);
    virtual ~Cliente();
    
    void SetCategoria(char categoria);
    char GetCategoria() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetNombre(const char *cad);
    void GetNombre(char *cad) const;
    
    void cargacliente(int d, char c, char *n);
    
    void leercliente(ifstream &arch);
    
    void imprimircliente(ofstream& arch);
    
private:
    int dni;
    char categoria;
    char *nombre;
};

#endif /* CLIENTE_H */

