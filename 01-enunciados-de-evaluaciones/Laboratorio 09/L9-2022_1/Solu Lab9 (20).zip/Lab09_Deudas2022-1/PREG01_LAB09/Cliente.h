/* 
 * Proyecto: PREG01_LAB09
 * File:   Cliente.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 24 de junio de 2022, 8:04
 */

#ifndef CLIENTE_H
#define CLIENTE_H

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

class Cliente {
public:
    Cliente();
    Cliente(const Cliente& orig);
    virtual ~Cliente();
    
    void SetTotalped(double totalped);
    double GetTotalped() const;
    void SetCantped(int cantped);
    int GetCantped() const;
    void SetCategoria(char categoria);
    char GetCategoria() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetNombre(const char *cad);
    void GetNombre(char *cad) const;
    
    void cargarcliente(int dniLeido, char catLeida, char* nom, int cantpedido, double totalpedido);
    
    virtual void lee(ifstream &arch, char categoria);
    virtual void imprime(ofstream &arch);
private:
    int dni;
    char categoria; // A, B, C
    char *nombre;
    int cantped; // cantidad de pedidos
    double totalped; // monto toal de los pedidos de un cliente
};

#endif /* CLIENTE_H */

