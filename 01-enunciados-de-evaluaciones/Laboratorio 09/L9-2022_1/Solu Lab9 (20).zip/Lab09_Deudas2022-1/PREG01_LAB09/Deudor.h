/* 
 * Proyecto: PREG01_LAB09
 * File:   Deudor.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 24 de junio de 2022, 8:15
 */

#ifndef DEUDOR_H
#define DEUDOR_H

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "Cliente.h"

class Deudor {
public:
    Deudor();
    Deudor(const Deudor& orig);
    virtual ~Deudor();
    
    void leerdeudor(ifstream &arch);
    int validadeudor();
    
    void imprimirdeudor(ofstream &arch);
    
private:
    Cliente *Cdeudor;
};

#endif /* DEUDOR_H */

