/* 
 * Proyecto: PREG01_LAB09
 * File:   Cliente.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 24 de junio de 2022, 8:04
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Cliente.h"

Cliente::Cliente() {
    dni = 0;
    categoria = '-';
    nombre = nullptr;
    cantped = 0;
    totalped = 0;    
}

Cliente::Cliente(const Cliente& orig) {
}

Cliente::~Cliente() {
    if(nombre != nullptr) delete nombre;
}

// ---------------------------------------------------------------------------

void Cliente::SetTotalped(double totalped) {
    this->totalped = totalped;
}

double Cliente::GetTotalped() const {
    return totalped;
}

void Cliente::SetCantped(int cantped) {
    this->cantped = cantped;
}

int Cliente::GetCantped() const {
    return cantped;
}

void Cliente::SetCategoria(char categoria) {
    this->categoria = categoria;
}

char Cliente::GetCategoria() const {
    return categoria;
}

void Cliente::SetDni(int dni) {
    this->dni = dni;
}

int Cliente::GetDni() const {
    return dni;
}

void Cliente::SetNombre(const char *cad) {
    if(nombre != nullptr) delete nombre;
    nombre = new char[strlen(cad) + 1];
    strcpy(nombre, cad);
}

void Cliente::GetNombre(char *cad) const {
    if (nombre == nullptr) cad[0] = 0;
    else strcpy(cad, nombre);
}

void Cliente::cargarcliente(int dniLeido, char catLeida, char* nom, int cantpedido, double totalpedido) {
    SetDni(dniLeido);
    SetCategoria(catLeida);
    SetNombre(nom);
    SetCantped(cantpedido);
    SetTotalped(totalpedido);
}

// ---------------------------------------------------------------------------

void Cliente::lee(ifstream& arch, char categoria) {
    int dniLeido;
    char nombre[200];
    
    arch >> dniLeido;
    arch.get(); // coma
    arch.getline(nombre, 200);
    
    cargarcliente(dniLeido, categoria, nombre, 0, 0);
}

void Cliente::imprime(ofstream& arch) {
    arch << left << setw(15) << dni << nombre << endl;
    for (int l = 0; l < 62; l++) arch.put('-');
    arch << endl;
}
