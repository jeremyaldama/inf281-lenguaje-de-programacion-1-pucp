/* 
 * Proyecto: PREG01_LAB09
 * File:   ClienteB.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 24 de junio de 2022, 8:10
 */

#ifndef CLIENTEB_H
#define CLIENTEB_H

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "Cliente.h"

class ClienteB : public Cliente{
public:
    ClienteB();
    ClienteB(const ClienteB& orig);
    virtual ~ClienteB();
    
    void SetFlete(double flete);
    double GetFlete() const;
    void SetDescuento(double descuento);
    double GetDescuento() const;
    
    void lee(ifstream &arch, char categoria);
    void imprime(ofstream &arch);
private:
    double descuento;
    double flete; // incremento o cargo por gastos de envio
};

#endif /* CLIENTEB_H */

