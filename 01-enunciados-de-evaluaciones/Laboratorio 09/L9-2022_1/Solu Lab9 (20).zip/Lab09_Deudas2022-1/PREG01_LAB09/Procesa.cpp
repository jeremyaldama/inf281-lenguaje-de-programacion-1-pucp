/* 
 * Proyecto: PREG01_LAB09
 * File:   Procesa.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 24 de junio de 2022, 8:16
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Procesa.h"

Procesa::Procesa() {
}

Procesa::Procesa(const Procesa& orig) {
}

Procesa::~Procesa() {
}

// ---------------------------------------------------------------------------

void Procesa::carga() {
    cargapedidos();
    cargadeudores();
}

void Procesa::cargapedidos() {
    ifstream arch("pedidos4.csv",ios::in);
    if(!arch){
        cout << "No se puede abrir los pedidos4";
        exit(1);
    }
    
    int i=0;
    while(1){
        lpedidos[i].leerpedido(arch);
        if(arch.eof()) break;
        i++;
    }
}

void Procesa::cargadeudores() {
    ifstream arch("clientes3.csv",ios::in);
    if(!arch){
        cout << "No se puede abrir los clientes3";
        exit(1);
    }
    
    int i=0;
    while(1){
        ldeudor[i].leerdeudor(arch);
        if(arch.eof()) break;
        i++;
    }
}


// ---------------------------------------------------------------------------

void Procesa::actualiza() {
    // Se implementa en la pregunta 2
}

// ---------------------------------------------------------------------------

void Procesa::muestra() {
    ofstream arch("reporte.txt",ios::out);
    if(!arch){
        cout << "No se pudo abrir las reporte";
        exit(1);
    }
    arch << setprecision(2) << fixed;
    
    arch << setw(10) << " " << "REPORTE DE DEUDAS" << endl;
    for (int l = 0; l < 62; l++) arch.put('=');
    arch << endl;
    
    for(int i=0; ldeudor[i].validadeudor(); i++){
        ldeudor[i].imprimirdeudor(arch);
    }
}


// ---------------------------------------------------------------------------