/* 
 * Proyecto: PREG01_LAB09
 * File:   ClienteC.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 24 de junio de 2022, 8:11
 */

#ifndef CLIENTEC_H
#define CLIENTEC_H

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "Cliente.h"

class ClienteC : public Cliente{
public:
    ClienteC();
    ClienteC(const ClienteC& orig);
    virtual ~ClienteC();
    
    void SetFlete(double flete);
    double GetFlete() const;
    
    void lee(ifstream &arch, char categoria);
    void imprime(ofstream &arch);
private:
    double flete; // porcentaje de flete
};

#endif /* CLIENTEC_H */

