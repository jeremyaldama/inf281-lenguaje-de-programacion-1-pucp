/* 
 * Proyecto: PREG01_LAB09
 * File:   Procesa.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 24 de junio de 2022, 8:16
 */

#ifndef PROCESA_H
#define PROCESA_H

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "Pedido.h"
#include "Deudor.h"

class Procesa {
public:
    Procesa();
    Procesa(const Procesa& orig);
    virtual ~Procesa();
    
    void carga();
    void cargapedidos();
    void cargadeudores();
    
    void actualiza();
    void muestra();
    
private:
    Pedido lpedidos[200];
    Deudor ldeudor[100];
};

#endif /* PROCESA_H */

