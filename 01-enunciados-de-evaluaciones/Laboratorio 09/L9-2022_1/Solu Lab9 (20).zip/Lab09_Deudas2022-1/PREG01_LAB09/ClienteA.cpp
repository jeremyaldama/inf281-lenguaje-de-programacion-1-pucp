/* 
 * Proyecto: PREG01_LAB09
 * File:   ClienteA.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 24 de junio de 2022, 8:09
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Cliente.h"
#include "ClienteA.h"

ClienteA::ClienteA() {
    descuento = 0;
}

ClienteA::ClienteA(const ClienteA& orig) {
}

ClienteA::~ClienteA() {
}

// ---------------------------------------------------------------------------

void ClienteA::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double ClienteA::GetDescuento() const {
    return descuento;
}

// ---------------------------------------------------------------------------

void ClienteA::lee(ifstream& arch, char categoria) {
    arch >> descuento;
    arch.get();
    
    Cliente::lee(arch, categoria);
}

// ---------------------------------------------------------------------------

void ClienteA::imprime(ofstream& arch) {
    Cliente::imprime(arch);
    arch << left << setw(12) << "Descuento:" << right <<setw(10) << descuento << "%" << endl <<
            left << setw(12) << "Total:" << right <<setw(10) << GetTotalped() << endl <<
            left << setw(20) << "Cantidad de Pedidos:" << right <<setw(10) << GetCantped() << endl << endl;
}

// ---------------------------------------------------------------------------