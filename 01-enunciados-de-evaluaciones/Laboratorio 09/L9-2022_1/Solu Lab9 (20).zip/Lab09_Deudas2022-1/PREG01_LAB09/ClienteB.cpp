/* 
 * Proyecto: PREG01_LAB09
 * File:   ClienteB.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 24 de junio de 2022, 8:10
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Cliente.h"
#include "ClienteB.h"

ClienteB::ClienteB() {
    descuento = 0;
    flete = 0;
}

ClienteB::ClienteB(const ClienteB& orig) {
}

ClienteB::~ClienteB() {
}

// ---------------------------------------------------------------------------

void ClienteB::SetFlete(double flete) {
    this->flete = flete;
}

double ClienteB::GetFlete() const {
    return flete;
}

void ClienteB::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double ClienteB::GetDescuento() const {
    return descuento;
}

// ---------------------------------------------------------------------------

void ClienteB::lee(ifstream& arch, char categoria) {
    char c;
    
    arch >> descuento >> c >> flete;
    arch.get();
    
    Cliente::lee(arch, categoria);
}

// ---------------------------------------------------------------------------

void ClienteB::imprime(ofstream& arch) {
    Cliente::imprime(arch);
    arch << left << setw(12) << "Descuento:" << right << setw(10) << descuento << "%"<< "  " <<
            left << setw(12) << "Flete:" << right << setw(10) << flete << "%" <<endl <<
            left << setw(12) << "Total:" << right <<setw(10) << GetTotalped() << endl <<
            left << setw(20) << "Cantidad de Pedidos:" << right <<setw(10) << GetCantped() << endl << endl;
}
