/* 
 * Proyecto: PREG01_LAB09
 * File:   ClienteA.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 24 de junio de 2022, 8:09
 */

#ifndef CLIENTEA_H
#define CLIENTEA_H

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "Cliente.h"

class ClienteA : public Cliente{
public:
    ClienteA();
    ClienteA(const ClienteA& orig);
    virtual ~ClienteA();
    
    void SetDescuento(double descuento);
    double GetDescuento() const;
    
    void lee(ifstream &arch, char categoria);
    void imprime(ofstream &arch);
private:
    double descuento;
};

#endif /* CLIENTEA_H */

