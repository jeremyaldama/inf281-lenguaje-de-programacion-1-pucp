/* 
 * Proyecto: PREG02_LAB09
 * File:   Pedido.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 24 de junio de 2022, 8:13
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Pedido.h"

Pedido::Pedido() {
    codigo = 0;
    cantidad = 0;
    dni = 0;
    fecha = 0;
    total = 0;
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
}

// ---------------------------------------------------------------------------

void Pedido::SetTotal(double total) {
    this->total = total;
}

double Pedido::GetTotal() const {
    return total;
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetDni(int dni) {
    this->dni = dni;
}

int Pedido::GetDni() const {
    return dni;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}

void Pedido::cargarpedido(int cod, int cant, int d, int f, double tot) {
    SetCodigo(cod);
    SetCantidad(cant);
    SetDni(d);
    SetFecha(f);
    SetTotal(tot);
}


// ---------------------------------------------------------------------------

void Pedido::leerpedido(ifstream& arch) {
    int codLeido, cant, dd, mm, aa, fecha, dniLeido;
    double monto;
    char c;
    
    arch >> codLeido;
    if(arch.eof()) return;
    arch.get(); // coma
    
    arch >> cant >> c >> monto >> c >> dniLeido >> c >> dd >> c >> mm >> c >> aa;
    fecha = dd + mm*100 + aa*10000;
    
    cargarpedido(codLeido, cant, dniLeido, fecha, monto);
}

// ---------------------------------------------------------------------------