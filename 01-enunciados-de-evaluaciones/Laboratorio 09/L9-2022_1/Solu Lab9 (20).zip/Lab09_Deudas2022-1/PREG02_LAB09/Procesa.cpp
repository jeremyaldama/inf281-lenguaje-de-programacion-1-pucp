/* 
 * Proyecto: PREG02_LAB09
 * File:   Procesa.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 24 de junio de 2022, 8:16
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Procesa.h"

Procesa::Procesa() {
}

Procesa::Procesa(const Procesa& orig) {
}

Procesa::~Procesa() {
}

// ---------------------------------------------------------------------------

void Procesa::carga() {
    cargapedidos();
    cargadeudores();
}

void Procesa::cargapedidos() {
    ifstream arch("pedidos4.csv",ios::in);
    if(!arch){
        cout << "No se puede abrir los pedidos4";
        exit(1);
    }
    
    int i=0;
    while(1){
        lpedidos[i].leerpedido(arch);
        if(arch.eof()) break;
        i++;
    }
}

void Procesa::cargadeudores() {
    ifstream arch("clientes3.csv",ios::in);
    if(!arch){
        cout << "No se puede abrir los clientes3";
        exit(1);
    }
    
    int i=0;
    while(1){
        ldeudor[i].leerdeudor(arch);
        if(arch.eof()) break;
        i++;
    }
}


// ---------------------------------------------------------------------------

void Procesa::actualiza() {
    int dni;
    for(int i=0; ldeudor[i].validadeudor(); i++){
        dni = ldeudor[i].GetDniDeudor();
        contarpedidos(i, dni);
    }
}

void Procesa::contarpedidos(int posCliente, int dni){
    int cantPedidos = 0;
    double montoTotal = 0, monto;
    
    for(int i=0; lpedidos[i].GetCodigo(); i++){
        if(lpedidos[i].GetDni() == dni){
            monto = lpedidos[i].GetTotal();
            montoTotal += ldeudor[posCliente].obtenermonto(monto);
            cantPedidos++;
        }
    }
    ldeudor[posCliente].actualizarpedidos(cantPedidos, montoTotal);
}

// ---------------------------------------------------------------------------

void Procesa::muestra() {
    ofstream arch("reporteFinal.txt",ios::out);
    if(!arch){
        cout << "No se pudo abrir las reporteFinal";
        exit(1);
    }
    arch << setprecision(3) << fixed;
    
    arch << setw(10) << " " << "REPORTE DE DEUDAS" << endl;
    for (int l = 0; l < 62; l++) arch.put('=');
    arch << endl;
    
    for(int i=0; ldeudor[i].validadeudor(); i++){
        ldeudor[i].imprimirdeudor(arch);
    }
}


// ---------------------------------------------------------------------------