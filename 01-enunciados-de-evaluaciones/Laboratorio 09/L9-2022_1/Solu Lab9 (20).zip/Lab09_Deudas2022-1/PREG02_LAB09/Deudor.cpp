/* 
 * Proyecto: PREG02_LAB09
 * File:   Deudor.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 24 de junio de 2022, 8:15
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Deudor.h"
#include "ClienteA.h"
#include "ClienteB.h"
#include "ClienteC.h"

Deudor::Deudor() {
    Cdeudor = nullptr;
}

Deudor::Deudor(const Deudor& orig) {
}

Deudor::~Deudor() {
    if(Cdeudor != nullptr) delete Cdeudor;
}

// ---------------------------------------------------------------------------

void Deudor::leerdeudor(ifstream& arch) {
    char categoria;
    
    arch >> categoria;
    if(arch.eof()) return;
    arch.get(); // coma
    
    if(categoria == 'A') Cdeudor = new ClienteA;
    if(categoria == 'B') Cdeudor = new ClienteB;
    if(categoria == 'C') Cdeudor = new ClienteC;
    
    Cdeudor->lee(arch, categoria);
}

int Deudor::validadeudor() {
    if(Cdeudor == nullptr) return 0;
    else return 1;
}

// ---------------------------------------------------------------------------

void Deudor::imprimirdeudor(ofstream& arch) {
    Cdeudor->imprime(arch);
}

// ---------------------------------------------------------------------------

int Deudor::GetDniDeudor(){
    Cdeudor->GetDni();
}

double Deudor::obtenermonto(double monto){
    double descuento, flete, montoDescuento, montoFlete;
    
    descuento = Cdeudor->GetDescuento();
    flete = Cdeudor->GetFlete();
    
    montoDescuento = monto*(descuento/100);
    montoFlete = monto*(flete/100);
    
    return monto - montoDescuento + montoFlete;
}

void Deudor::actualizarpedidos(int cantPedidos, double montoTotal){
    Cdeudor->SetCantped(cantPedidos);
    Cdeudor->SetTotalped(montoTotal);
}