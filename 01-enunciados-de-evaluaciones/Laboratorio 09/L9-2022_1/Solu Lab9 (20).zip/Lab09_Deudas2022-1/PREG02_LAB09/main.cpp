/* 
 * Proyecto: PREG02_LAB09
 * File:   main.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 24 de junio de 2022, 8:04
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>
using namespace std;

#include "Procesa.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    Procesa pro;
    
    pro.carga();
    pro.actualiza();
    pro.muestra();
    
    return 0;
}

