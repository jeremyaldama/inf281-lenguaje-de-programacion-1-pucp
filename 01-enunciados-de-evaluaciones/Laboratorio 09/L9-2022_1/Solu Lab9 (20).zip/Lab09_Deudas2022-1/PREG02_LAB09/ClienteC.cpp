/* 
 * Proyecto: PREG02_LAB09
 * File:   ClienteC.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 24 de junio de 2022, 8:11
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Cliente.h"
#include "ClienteC.h"

ClienteC::ClienteC() {
    flete = 0;
}

ClienteC::ClienteC(const ClienteC& orig) {
}

ClienteC::~ClienteC() {
}

// ---------------------------------------------------------------------------

void ClienteC::SetFlete(double flete) {
    this->flete = flete;
}

double ClienteC::GetFlete() const {
    return flete;
}

// ---------------------------------------------------------------------------

void ClienteC::lee(ifstream& arch, char categoria) {
    arch >> flete;
    arch.get();
    
    Cliente::lee(arch, categoria);
}

void ClienteC::imprime(ofstream& arch) {
    Cliente::imprime(arch);
    arch << left << setw(12) << "Flete:" << right << setw(10) << flete << "%" << endl <<
            left << setw(12) << "Total:" << right <<setw(10) << GetTotalped() << endl <<
            left << setw(20) << "Cantidad de Pedidos:" << right <<setw(10) << GetCantped() << endl << endl;
}

double ClienteC::GetDescuento() const {
    return 0;
}