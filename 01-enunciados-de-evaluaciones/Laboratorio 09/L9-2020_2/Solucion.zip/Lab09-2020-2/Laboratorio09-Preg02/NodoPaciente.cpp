/* 
 * Archivo:   NodoPaciente.cpp
 * Autor: Oscar Dueñas Damian - Oscar DD.
 * Codigo PUCP: 20180146
 * Created on 11 de diciembre de 2020, 08:45 AM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "NodoPaciente.h"

NodoPaciente::NodoPaciente() {
    next = nullptr;
}

NodoPaciente::~NodoPaciente() {

}
