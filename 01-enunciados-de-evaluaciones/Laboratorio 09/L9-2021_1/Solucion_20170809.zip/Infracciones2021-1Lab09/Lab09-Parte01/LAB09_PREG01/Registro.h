/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Registro.h
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 2 de julio de 2021, 08:06 AM
 */

#ifndef REGISTRO_H
#define REGISTRO_H
#include "Conductor.h"
#include "Falta.h"

class Registro : public Conductor, public Falta {
private:
    class Infraccion *pfalta;

public:
    Registro();
    Registro(const Registro& orig);
    virtual ~Registro();
    void SetInfraccion(Infraccion *);
    Infraccion* GetInfraccion() const;
    
    void leerConductor(int);
    void cargarInfraccion(int);
};

#endif /* REGISTRO_H */

