/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Procesa.h
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 2 de julio de 2021, 08:06 AM
 */

#ifndef PROCESA_H
#define PROCESA_H
#include "Registro.h"

class Procesa {
private:
    class Registro lregistro[1000];
    int cantidad;

public:
    Procesa();
    Procesa(const Procesa& orig);
    virtual ~Procesa();
    
    void leer();
    void imprimir();
};

#endif /* PROCESA_H */

