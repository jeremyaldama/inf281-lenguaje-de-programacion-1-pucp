/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Grave.cpp
 * Author: Alonso
 * 
 * Created on 2 de julio de 2021, 08:05 AM
 */

#include "Grave.h"

Grave::Grave() {
    descuento=0;
    puntos=0;
}

Grave::Grave(const Grave& orig) {
}

Grave::~Grave() {
}

void Grave::SetPuntos(int puntos) {
    this->puntos = puntos;
}

int Grave::GetPuntos() const {
    return puntos;
}

void Grave::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double Grave::GetDescuento() const {
    return descuento;
}

void Grave::lee(ifstream &archInfraccion, int codInfraccion) {
    
    int codInfraccionAux, puntos;
    char aux[500];
    double montoMulta,descuento;
    
    while(1){
        archInfraccion>>codInfraccionAux;
        if(archInfraccion.eof()) break;
        if(codInfraccion==codInfraccionAux){
            archInfraccion.get();
            archInfraccion.getline(aux,500,','); //descripcion
            archInfraccion.getline(aux,500,',');  //gravedad
            SetGravedad(aux);
            archInfraccion>>montoMulta;
            SetMulta(montoMulta);
            archInfraccion.get();
            
            archInfraccion>>descuento;
            archInfraccion.get();
            archInfraccion>>puntos;
            SetDescuento(descuento);
            SetPuntos(puntos);
        }
        else while(archInfraccion.get()!='\n'); //Si no es el codInfraccion se salta toda la linea
    }
}

void Grave::imprime(ofstream &archReporte) {
    char aux[100];
    archReporte<<"Codigo Infraccion: "<<GetCodigo()<<endl;
    GetGravedad(aux);
    archReporte<<"Gravedad: "<<aux<<endl;
    archReporte<<"Monto Multa: "<<GetMulta()<<endl; //Para este metodo no se aplica el descuento, indicacion del profesor Cueva
    
    archReporte<<"Descuento: "<<GetDescuento()<<endl;
    archReporte<<"Puntos: "<<GetPuntos()<<endl<<endl;
}