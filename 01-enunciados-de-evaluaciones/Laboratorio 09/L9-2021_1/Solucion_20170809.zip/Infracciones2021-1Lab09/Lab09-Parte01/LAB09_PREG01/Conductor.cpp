/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Conductor.cpp
 * Author: Alonso
 * 
 * Created on 2 de julio de 2021, 08:05 AM
 */

#include <cstring>
#include "Conductor.h"

Conductor::Conductor() {
    licencia=0;
    nombre=nullptr;
}

Conductor::Conductor(const Conductor& orig) {
}

Conductor::~Conductor() {
}

void Conductor::SetNombre(char *aux) {
    if(nombre!=nullptr) delete nombre;
    nombre=new char [strlen(aux)+1];
    strcpy(nombre,aux);
}

void Conductor::GetNombre(char *aux) const {
    if(nombre==nullptr) aux[0]=0;
    strcpy(aux,nombre);
}

void Conductor::SetLicencia(int licencia) {
    this->licencia = licencia;
}

int Conductor::GetLicencia() const {
    return licencia;
}