/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Conductor.h
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 2 de julio de 2021, 08:05 AM
 */

#ifndef CONDUCTOR_H
#define CONDUCTOR_H

class Conductor {
private:
    int licencia;
    char *nombre;

public:
    Conductor();
    Conductor(const Conductor& orig);
    virtual ~Conductor();
    
    void SetNombre(char* );
    void GetNombre(char* ) const;
    void SetLicencia(int licencia);
    int GetLicencia() const;
};

#endif /* CONDUCTOR_H */

