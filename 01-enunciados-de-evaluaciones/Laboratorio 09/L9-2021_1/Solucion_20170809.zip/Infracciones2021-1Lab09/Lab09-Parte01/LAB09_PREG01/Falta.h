/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Falta.h
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 2 de julio de 2021, 08:05 AM
 */

#ifndef FALTA_H
#define FALTA_H

class Falta {
private:
    int fecha;
    char *placa;

public:
    Falta();
    Falta(const Falta& orig);
    virtual ~Falta();
    void SetPlaca(char* );
    void GetPlaca(char*) const;
    void SetFecha(int fecha);
    int GetFecha() const;
};

#endif /* FALTA_H */

