/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MuyGrave.cpp
 * Author: Alonso
 * 
 * Created on 2 de julio de 2021, 08:05 AM
 */

#include "MuyGrave.h"

MuyGrave::MuyGrave() {
    meses=0;
    puntos=0;
}

MuyGrave::MuyGrave(const MuyGrave& orig) {
}

MuyGrave::~MuyGrave() {
}

void MuyGrave::setMeses(int meses) {
    this->meses = meses;
}

int MuyGrave::getMeses() const {
    return meses;
}

void MuyGrave::setPuntos(int puntos) {
    this->puntos = puntos;
}

int MuyGrave::getPuntos() const {
    return puntos;
}

void MuyGrave::lee(ifstream &archInfraccion, int codInfraccion) {
    
    int codInfraccionAux, puntos, meses;
    char aux[500];
    double montoMulta;
    
    while(1){
        archInfraccion>>codInfraccionAux;
        if(archInfraccion.eof()) break;
        if(codInfraccion==codInfraccionAux){
            archInfraccion.get();
            archInfraccion.getline(aux,500,','); //descripcion
            archInfraccion.getline(aux,500,',');  //gravedad
            SetGravedad(aux);
            archInfraccion>>montoMulta;
            SetMulta(montoMulta);
            archInfraccion.get();
            
            archInfraccion>>puntos;
            archInfraccion.get();
            archInfraccion>>meses;
            setPuntos(puntos);
            setMeses(meses);
        }
        else while(archInfraccion.get()!='\n'); //Si no es el codInfraccion se salta toda la linea
    }
}

void MuyGrave::imprime(ofstream &archReporte) {
    char aux[100];
    archReporte<<"Codigo Infraccion: "<<GetCodigo()<<endl;
    GetGravedad(aux);
    archReporte<<"Gravedad: "<<aux<<endl;
    archReporte<<"Monto Multa: "<<GetMulta()<<endl;
    
    archReporte<<"Puntos: "<<getPuntos()<<endl;
    archReporte<<"Meses: "<<getMeses()<<endl<<endl;
}