/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Registro.cpp
 * Author: Alonso
 * 
 * Created on 2 de julio de 2021, 08:06 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
#include "Registro.h"
#include "Infraccion.h"
#include "Falta.h"
#include "Grave.h"
#include "MuyGrave.h"
#include "Leve.h"

Registro::Registro() {
    pfalta=nullptr;
}

Registro::Registro(const Registro& orig) {
}

Registro::~Registro() {
}

void Registro::SetInfraccion(Infraccion *infraccion) { //Le da la direccion de memoria a donde va apuntar la nueva infraccion
    this->pfalta = infraccion;
}

Infraccion* Registro::GetInfraccion() const {
    return pfalta;
}

void Registro::leerConductor(int numLicencia) {
    ifstream archConductores("Conductores.csv",ios::in);
    if(!archConductores){
        cout<<"ERROR: NO se puede abrir el archivo Conductores.csv"<<endl;
        exit(1);
    }
    
    int numLicenciaArch;
    char nombreArch[100];
    
    while(1){
        archConductores>>numLicenciaArch;
        if(archConductores.eof()) break;
        archConductores.get();
        archConductores.getline(nombreArch,100);
        if(numLicencia==numLicenciaArch){
            SetNombre(nombreArch);
            return;
        }
    }
}

void Registro::cargarInfraccion(int codInfraccion) {
    ifstream archInfraccion("Infracciones.csv",ios::in);
    if(!archInfraccion){
        cout<<"ERROR: NO se puede abrir el archivo Infracciones.csv"<<endl;
        exit(1);
    }
   
    
    if(codInfraccion/100==2){
        pfalta=new Leve;
    }
    else if(codInfraccion/100==1){
        pfalta=new Grave;
    }
    else if(codInfraccion/100==3){
        pfalta=new MuyGrave;
    }
    
    pfalta->SetCodigo(codInfraccion);
    pfalta->lee(archInfraccion,codInfraccion);
}

