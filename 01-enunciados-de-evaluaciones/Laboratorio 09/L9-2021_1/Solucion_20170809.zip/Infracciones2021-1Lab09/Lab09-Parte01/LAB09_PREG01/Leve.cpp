/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Leve.cpp
 * Author: Alonso
 * 
 * Created on 2 de julio de 2021, 08:05 AM
 */

#include "Leve.h"

Leve::Leve() {
    descuento=0.0;
}

Leve::Leve(const Leve& orig) {
}

Leve::~Leve() {
}

void Leve::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double Leve::GetDescuento() const {
    return descuento;
}

void Leve::lee(ifstream &archInfraccion, int codInfraccion) {
    
    int codInfraccionAux;
    char aux[500];
    double montoMulta,descuento;
    
    while(1){
        archInfraccion>>codInfraccionAux;
        if(archInfraccion.eof()) break;
        if(codInfraccion==codInfraccionAux){
            archInfraccion.get();
            archInfraccion.getline(aux,500,','); //descripcion
            archInfraccion.getline(aux,500,',');  //gravedad
            SetGravedad(aux);
            archInfraccion>>montoMulta;
            SetMulta(montoMulta);
            archInfraccion.get();
            
            archInfraccion>>descuento;
            SetDescuento(descuento);
        }
        else while(archInfraccion.get()!='\n'); //Si no es el codInfraccion se salta toda la linea
    }
}

void Leve::imprime(ofstream &archReporte) {
    char aux[100];
    archReporte<<"Codigo Infraccion: "<<GetCodigo()<<endl;
    GetGravedad(aux);
    archReporte<<"Gravedad: "<<aux<<endl;
    archReporte<<"Monto Multa: "<<GetMulta()<<endl; //Para este metodo no se aplica el descuento, indicacion del profesor Cueva
    
    archReporte<<"Descuento: "<<GetDescuento()<<endl<<endl;
}


