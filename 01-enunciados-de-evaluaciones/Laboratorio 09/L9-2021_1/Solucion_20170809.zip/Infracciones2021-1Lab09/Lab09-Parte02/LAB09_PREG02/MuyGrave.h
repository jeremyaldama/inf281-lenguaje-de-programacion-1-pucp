/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MuyGrave.h
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 2 de julio de 2021, 08:05 AM
 */

#ifndef MUYGRAVE_H
#define MUYGRAVE_H
#include "Infraccion.h"
#include <fstream>
using namespace std;

class MuyGrave : public Infraccion {
private:
    int puntos;
    int meses;

public:
    MuyGrave();
    MuyGrave(const MuyGrave& orig);
    virtual ~MuyGrave();
    void setMeses(int meses);
    int getMeses() const;
    void setPuntos(int puntos);
    int getPuntos() const;
    
    void lee(ifstream &, int);
    void imprime(ofstream &);
    void aplica();
    void acumularDatos(int &,int &,double &);
};

#endif /* MUYGRAVE_H */

