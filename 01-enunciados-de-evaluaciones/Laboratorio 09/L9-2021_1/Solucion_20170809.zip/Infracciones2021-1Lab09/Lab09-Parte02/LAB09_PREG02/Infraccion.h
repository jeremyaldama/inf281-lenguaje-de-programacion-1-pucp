/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Infraccion.h
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 2 de julio de 2021, 08:05 AM
 */

#ifndef INFRACCION_H
#define INFRACCION_H
#include <fstream>
using namespace std;

class Infraccion {
private:
    int codigo;
    char *gravedad;
    double multa;

public:
    Infraccion();
    Infraccion(const Infraccion& orig);
    virtual ~Infraccion();
    void SetMulta(double multa);
    double GetMulta() const;
    void SetGravedad(char* );
    void GetGravedad(char*) const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    
    virtual void lee(ifstream &, int)=0;
    virtual void imprime(ofstream &)=0;
    virtual void aplica()=0;
    virtual void acumularDatos(int &,int &,double &)=0;
};

#endif /* INFRACCION_H */

