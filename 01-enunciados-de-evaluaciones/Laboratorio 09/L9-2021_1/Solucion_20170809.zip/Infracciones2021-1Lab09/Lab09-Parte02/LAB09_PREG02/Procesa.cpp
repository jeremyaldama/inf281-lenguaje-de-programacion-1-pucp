/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Procesa.cpp
 * Author: Alonso
 * 
 * Created on 2 de julio de 2021, 08:06 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
using namespace std;
#include "Procesa.h"
#include "Infraccion.h"
#include "Leve.h"
#include "Grave.h"
#include "MuyGrave.h"
#define MAX_LINEA 200

Procesa::Procesa() { 
    cantidad=0;
}

Procesa::Procesa(const Procesa& orig) {
}

Procesa::~Procesa() {
}

void Procesa::leer() {
    ifstream archRegistroDeFaltas("RegistroDeFaltas.csv",ios::in);
    if(!archRegistroDeFaltas){
        cout<<"ERROR: NO se puede abrir el archivo RegistroDeFaltas"<<endl;
        exit(1);
    }
    
    int licencia,codInfraccion,dd,mm,aa,fecha;
    char car, placa[10];
    
    while(1){
        archRegistroDeFaltas>>licencia;
        if(archRegistroDeFaltas.eof()) break;
        archRegistroDeFaltas.get();
        archRegistroDeFaltas>>codInfraccion;
        archRegistroDeFaltas.get();
        archRegistroDeFaltas>>dd>>car>>mm>>car>>aa;
        archRegistroDeFaltas.get();
        archRegistroDeFaltas>>placa;
        
        fecha=aa*10000+mm*100+dd;
        
        lregistro[cantidad].SetLicencia(licencia);
        lregistro[cantidad].leerConductor(licencia); //carga el nombre del conductor
        lregistro[cantidad].SetFecha(fecha);
        lregistro[cantidad].SetPlaca(placa);
        
        lregistro[cantidad].cargarInfraccion(codInfraccion);
        
        cantidad++;
    }
}

void Procesa::imprimir() {
    ofstream archReporte("Reporte_PARTE01.txt",ios::out);
    if(!archReporte){
        cout<<"ERROR: NO se puede abrir el archivo Reporte.txt"<<endl;
        exit(1);
    }
    
    char aux[100];
    for(int i=0;lregistro[i].GetInfraccion();i++){
        archReporte<<"Licencia: "<<lregistro[i].GetLicencia()<<endl;
        archReporte<<"Fecha: "<<lregistro[i].GetFecha()<<endl;
        lregistro[i].GetPlaca(aux);
        archReporte<<"Placa: "<<aux<<endl;
        lregistro[i].GetInfraccion()->imprime(archReporte);
    }
}

void Procesa::aplicar() {
    for(int i=0;lregistro[i].GetInfraccion();i++){
        lregistro[i].GetInfraccion()->aplica();
    }
}

void Procesa::consolidar() {
    ifstream archSancionados("sancionados.csv",ios::out);
    if(!archSancionados){
        cout<<"ERROR: NO se puede abrir el archivo sancionados.csv"<<endl;
        exit(1);
    }
    
    ofstream archReporteConsolidado("ReporteConsolidado_PARTE02.txt",ios::out);
    if(!archSancionados){
        cout<<"ERROR: NO se puede abrir el archivo ReporteConsolidado.txt"<<endl;
        exit(1);
    }
    
    int numLicencia,numLicenciaAux,puntosPerdidos,mesesSancionados;
    char aux[100];
    double montoMultas;
    
    while(1){
        archSancionados>>numLicencia;
        if(archSancionados.eof()) break;
        
        puntosPerdidos=0;
        mesesSancionados=0;
        montoMultas=0.0;
        
        for(int i=0;lregistro[i].GetInfraccion();i++){
            if(lregistro[i].GetLicencia()==numLicencia){
                numLicenciaAux=lregistro[i].GetLicencia();
                lregistro[i].GetNombre(aux);
                lregistro[i].GetInfraccion()->acumularDatos(puntosPerdidos,mesesSancionados,montoMultas);
            }
        }
        
        archReporteConsolidado<<"Conductor    : "<<aux<<endl;
        archReporteConsolidado<<"Licencia No. : "<<numLicenciaAux<<endl;
        imprimirLinea('-',MAX_LINEA,archReporteConsolidado);
        archReporteConsolidado<<"Monto de Multas: "<<montoMultas<<endl;
        archReporteConsolidado<<"Puntos perdidos: "<<puntosPerdidos<<endl;
        archReporteConsolidado<<"Meses sancionados: "<<mesesSancionados<<endl<<endl;
    }
}

void Procesa::imprimirLinea(char car, int cant, ofstream &arch) {
    for(int i=0;i<cant;i++){
        arch<<car;
    }
    arch<<endl;
}



