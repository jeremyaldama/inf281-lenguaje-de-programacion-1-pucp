/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Leve.h
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 2 de julio de 2021, 08:05 AM
 */

#ifndef LEVE_H
#define LEVE_H
#include "Infraccion.h"
#include <fstream>
using namespace std;

class Leve : public Infraccion{
private:
    double descuento;

public:
    Leve();
    Leve(const Leve& orig);
    virtual ~Leve();
    void SetDescuento(double descuento);
    double GetDescuento() const;
    
    void lee(ifstream &, int);
    void imprime(ofstream &);
    void aplica();
    void acumularDatos(int &,int &,double &);
};

#endif /* LEVE_H */

