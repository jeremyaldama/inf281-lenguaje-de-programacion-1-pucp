/* 
 * Proyecto: LAB10_PREG02
 * File:   Lista.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 1 de julio de 2022, 8:11
 */

#ifndef LISTA_H
#define LISTA_H

#include <iostream>
#include <fstream>
#include <iomanip>

#include "Nodo.h"
using namespace std;

class Lista {
public:
    Lista();
    Lista(const Lista& orig);
    virtual ~Lista();
    
    void insertarnodo(ifstream& arch);
    void leerdatos(ifstream &arch, class Nodo *&ptrNuevo);
    int comparacion(const class Nodo *ptrRec, const class Nodo *ptrNuevo);
    
    void imprimirpedidos(ofstream &arch);
    
    void actualiza(int dni, int fecha);
private:
    Nodo *lini;
    Nodo *lfin;
};

#endif /* LISTA_H */

