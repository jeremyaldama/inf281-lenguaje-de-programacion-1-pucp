/* 
 * Proyecto: LAB10_PREG02
 * File:   main.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 1 de julio de 2022, 8:02
 */

#include "Promociones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    Promociones pro;
    
    pro.leepedidos();
    pro.actualizapedidos();
    pro.imprimepedidos();
    
    return 0;
}

