/* 
 * Proyecto: LAB10_PREG02
 * File:   Promociones.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 1 de julio de 2022, 8:12
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Promociones.h"

Promociones::Promociones() {
}

Promociones::Promociones(const Promociones& orig) {
}

Promociones::~Promociones() {
}

// ---------------------------------------------------------------------------

void Promociones::leepedidos() {
    ifstream arch("pedidos5.csv",ios::in);
    if(!arch){
        cout << "No se puede abrir los pedidos5";
        exit(1);
    }
    
    while(1){
        Lpedidos.insertarnodo(arch);
        if(arch.eof()) break;
    }
}

// ---------------------------------------------------------------------------

void Promociones::imprimepedidos() {
    ofstream arch("reportePreg02.txt",ios::out);
    if(!arch){
        cout << "No se puede abrir los reportePreg02";
        exit(1);
    }
    arch << setprecision(2) << fixed;
    
    arch << setw(10) << " " << " REPORTE DE PROMOCIONES" << endl;
    for (int l = 0; l < 60; l++) arch.put('=');
    arch << endl;
    
    Lpedidos.imprimirpedidos(arch);
}

// ---------------------------------------------------------------------------

void Promociones::actualizapedidos() {
    ifstream arch("promocion.csv",ios::in);
    if(!arch){
        cout << "No se puede abrir los promocion";
        exit(1);
    }
    
    int dni, dd, mm, aa, fecha;
    char c;
    while(1){
        arch >> dni;
        if(arch.eof()) break;
        arch.get(); // coma
        
        arch >> dd >> c >> mm >> c >> aa;
        fecha = dd + mm*100 + aa*10000;
        
        Lpedidos.actualiza(dni, fecha);
    }
}
