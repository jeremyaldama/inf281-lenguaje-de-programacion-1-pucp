/* 
 * Proyecto: LAB10_PREG02
 * File:   Nodo.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 1 de julio de 2022, 8:09
 */

#ifndef NODO_H
#define NODO_H

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "Pedido.h"
#include "Lista.h"

class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    
    friend class Lista;
private:
    Pedido *ped;
    Nodo *sig;
    Nodo *ant;
};

#endif /* NODO_H */

