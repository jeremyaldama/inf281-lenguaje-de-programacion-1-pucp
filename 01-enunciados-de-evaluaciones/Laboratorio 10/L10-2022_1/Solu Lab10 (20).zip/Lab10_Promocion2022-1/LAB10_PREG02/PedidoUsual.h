/* 
 * Proyecto: LAB10_PREG02
 * File:   PedidoUsual.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 1 de julio de 2022, 8:07
 */

#ifndef PEDIDOUSUAL_H
#define PEDIDOUSUAL_H

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "Pedido.h"

class PedidoUsual : public Pedido {
public:
    PedidoUsual();
    PedidoUsual(const PedidoUsual& orig);
    virtual ~PedidoUsual();
    
    void SetFlete(double flete);
    double GetFlete() const;
    void SetDescuento(double descuento);
    double GetDescuento() const;
    
    void lee(ifstream &arch, int codigo, double descuento, double flete);
    void imprime(ofstream &arch);
    
    void exoneraflete();
private:
    double descuento;
    double flete;
};

#endif /* PEDIDOUSUAL_H */

