/* 
 * Proyecto: LAB10_PREG01
 * File:   Promociones.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 1 de julio de 2022, 8:12
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Promociones.h"

Promociones::Promociones() {
}

Promociones::Promociones(const Promociones& orig) {
}

Promociones::~Promociones() {
}

// ---------------------------------------------------------------------------

void Promociones::leepedidos() {
    ifstream arch("pedidos5.csv",ios::in);
    if(!arch){
        cout << "No se puede abrir los pedidos5";
        exit(1);
    }
    
    while(1){
        Lpedidos.insertarnodo(arch);
        if(arch.eof()) break;
    }
}

// ---------------------------------------------------------------------------

void Promociones::imprimepedidos() {
    ofstream arch("reportePreg01.txt",ios::out);
    if(!arch){
        cout << "No se puede abrir los reportePreg01";
        exit(1);
    }
    arch << setprecision(2) << fixed;
    
    arch << setw(10) << " " << " REPORTE DE PROMOCIONES" << endl;
    for (int l = 0; l < 60; l++) arch.put('=');
    arch << endl;
    
    Lpedidos.imprimirpedidos(arch);
}
