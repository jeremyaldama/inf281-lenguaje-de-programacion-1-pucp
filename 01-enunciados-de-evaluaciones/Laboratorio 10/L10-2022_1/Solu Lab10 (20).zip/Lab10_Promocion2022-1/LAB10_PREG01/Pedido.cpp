/* 
 * Proyecto: LAB10_PREG01
 * File:   Pedido.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 1 de julio de 2022, 8:03
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Pedido.h"

Pedido::Pedido() {
    codigo = 0;
    nombre = nullptr;
    cantidad = 0;
    dni = 0;
    fecha = 0;
    total = 0;
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
    if(nombre != nullptr) delete nombre;
}

// ---------------------------------------------------------------------------

void Pedido::SetTotal(double total) {
    this->total = total;
}

double Pedido::GetTotal() const {
    return total;
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetDni(int dni) {
    this->dni = dni;
}

int Pedido::GetDni() const {
    return dni;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}

void Pedido::SetNombre(const char *cad) {
    if(nombre != nullptr) delete nombre;
    nombre = new char[strlen(cad) + 1];
    strcpy(nombre, cad);
}

void Pedido::GetNombre(char *cad) const {
    if (nombre == nullptr) cad[0] = 0;
    else strcpy(cad, nombre);
}

void Pedido::cargarpedido(int codigo, char* nombre, int cantidad, int dni, int fecha, double total) {
    SetCodigo(codigo);
    SetNombre(nombre);
    SetCantidad(cantidad);
    SetDni(dni);
    SetFecha(fecha);
    SetTotal(total);
}

// ---------------------------------------------------------------------------

void Pedido::lee(ifstream& arch, int codigo, double descuento, double flete) {
    int cant, dniCliente, dd, mm, aa, fecha;
    char nombre[200], c;
    double monto;
    
    arch.getline(nombre, 200, ',');
    arch >> cant >> c >> monto >> c >> dniCliente >> c >> dd >> c >> mm >> c >> aa;
    fecha = dd + mm*100 + aa*10000;
    
    double montoDescuento = monto*(descuento/100);
    double montoFlete = monto*(flete/100);
    
    double montoactualizado = monto - montoDescuento + montoFlete;
    
    cargarpedido(codigo, nombre, cant, dniCliente, fecha, montoactualizado);
}

// ---------------------------------------------------------------------------

void Pedido::imprime(ofstream& arch) {
    imprimirfecha(arch);
    arch << endl;
    arch << left << setw(10) << codigo << nombre << endl <<
            left << setw(10) << "DNI:" << dni << endl <<
            left << setw(15) << "Monto total:" << right << setw(10) << total << endl;
}

void Pedido::imprimirfecha(ofstream& arch) {
    int dd, mm, aa;
    dd = fecha%100;
    mm = (fecha/100)%100;
    aa = (fecha/100)/100;
    arch << right << setfill('0') << setw(2) << dd << "/" << 
            setw(2) << mm << "/" <<
            setw(4) << aa << setfill(' ');
}
