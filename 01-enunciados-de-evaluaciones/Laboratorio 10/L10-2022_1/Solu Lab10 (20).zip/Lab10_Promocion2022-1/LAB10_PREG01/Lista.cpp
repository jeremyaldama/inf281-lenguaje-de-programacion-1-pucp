/* 
 * Proyecto: LAB10_PREG01
 * File:   Lista.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 1 de julio de 2022, 8:11
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Lista.h"
#include "PedidoEspecial.h"
#include "PedidoUsual.h"
#include "PedidoEventual.h"

Lista::Lista() {
    lini = nullptr;
    lfin = nullptr;
}

Lista::Lista(const Lista& orig) {
}

Lista::~Lista() {
    class Nodo *ptrRec;
    while (lini) {
        ptrRec = lini;
        lini = lini->sig;
        delete ptrRec;
    }
}

// ---------------------------------------------------------------------------

void Lista::insertarnodo(ifstream& arch) {
    class Nodo *ptrRec = lini, *ptrAnt = nullptr, *ptrNuevo = new Nodo;
    
    leerdatos(arch, ptrNuevo);
    if(arch.eof()) return;
    
    while (ptrRec) {
        if (comparacion(ptrRec, ptrNuevo)) break;
        ptrAnt = ptrRec;
        ptrRec = ptrRec->sig;
    }
    
    ptrNuevo->sig = ptrRec;
    ptrNuevo->ant = ptrAnt;
    
    if(lini == nullptr){ // primer dato
        lini = ptrNuevo;
        lfin = ptrNuevo;
    }else if(ptrAnt == nullptr){ // inicio
        lini->ant = ptrNuevo;
        lini = ptrNuevo;
    }else if(ptrRec == nullptr){ // fin
        lfin->sig = ptrNuevo;
        lfin = ptrNuevo;
    }else{ // medio
        ptrAnt->sig = ptrNuevo;
        ptrRec->ant = ptrNuevo;
    }
}

void Lista::leerdatos(ifstream &arch, class Nodo *&ptrNuevo){
    int codigo;
    
    arch >> codigo;
    if(arch.eof()) return;
    arch.get(); // coma
    
    if(codigo < 400000) ptrNuevo->ped = new PedidoEspecial;
    if(codigo >= 400000 && codigo < 600000) ptrNuevo->ped = new PedidoUsual;
    if(codigo >= 600000) ptrNuevo->ped = new PedidoEventual;
    
    ptrNuevo->ped->lee(arch, codigo, 0, 0);
}

int Lista::comparacion(const class Nodo *ptrRec, const class Nodo *ptrNuevo){
    if(ptrRec->ped->GetDni() != ptrNuevo->ped->GetDni()){
        return ptrRec->ped->GetDni() > ptrNuevo->ped->GetDni();
    }else{
        return ptrRec->ped->GetFecha() > ptrNuevo->ped->GetFecha();
    }
}

// ---------------------------------------------------------------------------

void Lista::imprimirpedidos(ofstream& arch) {
    class Nodo *ptrRec = lini;
    while (ptrRec) {
        arch << endl;
        ptrRec->ped->imprime(arch);
        ptrRec = ptrRec->sig;
    }
}
