/* 
 * Proyecto: LAB10_PREG01
 * File:   PedidoEspecial.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 1 de julio de 2022, 8:06
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "PedidoEspecial.h"

PedidoEspecial::PedidoEspecial() {
    descuento = 0;
}

PedidoEspecial::PedidoEspecial(const PedidoEspecial& orig) {
}

PedidoEspecial::~PedidoEspecial() {
}

// ---------------------------------------------------------------------------

void PedidoEspecial::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double PedidoEspecial::GetDescuento() const {
    return descuento;
}

// ---------------------------------------------------------------------------

void PedidoEspecial::lee(ifstream& arch, int codigo, double descuento, double flete) {
    char c;
    
    arch >> this->descuento >> c;
    Pedido::lee(arch, codigo, this->descuento, 0);
}

// ---------------------------------------------------------------------------

void PedidoEspecial::imprime(ofstream& arch) {
    Pedido::imprime(arch);
    arch << left << setw(15) << "Descuento:" << right << setw(10) << descuento << "%" << endl;
}
