/* 
 * Proyecto: LAB10_PREG01
 * File:   Promociones.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 1 de julio de 2022, 8:12
 */

#ifndef PROMOCIONES_H
#define PROMOCIONES_H

#include <iostream>
#include <fstream>
#include <iomanip>

#include "Lista.h"
using namespace std;

class Promociones {
public:
    Promociones();
    Promociones(const Promociones& orig);
    virtual ~Promociones();

    void leepedidos();
    void imprimepedidos();
private:
    Lista Lpedidos;
};

#endif /* PROMOCIONES_H */

