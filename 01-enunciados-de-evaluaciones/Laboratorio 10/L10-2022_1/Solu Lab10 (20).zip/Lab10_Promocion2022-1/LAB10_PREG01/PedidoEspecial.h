/* 
 * Proyecto: LAB10_PREG01
 * File:   PedidoEspecial.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 1 de julio de 2022, 8:06
 */

#ifndef PEDIDOESPECIAL_H
#define PEDIDOESPECIAL_H

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "Pedido.h"

// codigos menores a 400000
class PedidoEspecial : public Pedido {
public:
    PedidoEspecial();
    PedidoEspecial(const PedidoEspecial& orig);
    virtual ~PedidoEspecial();
    
    void SetDescuento(double descuento);
    double GetDescuento() const;
    
    void lee(ifstream &arch, int codigo, double descuento, double flete);
    void imprime(ofstream &arch);
private:
    double descuento;
};

#endif /* PEDIDOESPECIAL_H */

