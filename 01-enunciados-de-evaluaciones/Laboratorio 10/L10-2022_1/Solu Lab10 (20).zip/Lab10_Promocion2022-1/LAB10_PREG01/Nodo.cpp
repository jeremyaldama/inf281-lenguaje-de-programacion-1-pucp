/* 
 * Proyecto: LAB10_PREG01
 * File:   Nodo.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 1 de julio de 2022, 8:09
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "Nodo.h"

Nodo::Nodo() {
    ped = nullptr;
    sig = nullptr;
    ant = nullptr;
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
    if(ped != nullptr) delete ped;
}

// ---------------------------------------------------------------------------