/* 
 * Proyecto: LAB10_PREG01
 * File:   PedidoUsual.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 1 de julio de 2022, 8:07
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "PedidoUsual.h"

PedidoUsual::PedidoUsual() {
    descuento = 0;
    flete = 0;
}

PedidoUsual::PedidoUsual(const PedidoUsual& orig) {
}

PedidoUsual::~PedidoUsual() {
}

// ---------------------------------------------------------------------------

void PedidoUsual::SetFlete(double flete) {
    this->flete = flete;
}

double PedidoUsual::GetFlete() const {
    return flete;
}

void PedidoUsual::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double PedidoUsual::GetDescuento() const {
    return descuento;
}

// ---------------------------------------------------------------------------

void PedidoUsual::lee(ifstream& arch, int codigo, double descuento, double flete) {
    char c;
    
    arch >> this->descuento >> c >> this->flete >> c;
    Pedido::lee(arch, codigo, this->descuento, this->flete);
}


// ---------------------------------------------------------------------------

void PedidoUsual::imprime(ofstream& arch) {
    Pedido::imprime(arch);
    arch << left << setw(15) << "Descuento:" << right << setw(10) << descuento << "%" << endl;
    arch << left << setw(15) << "Flete:" << right << setw(10) << flete << "%" << endl;
}

