/* 
 * Proyecto: LAB10_PREG01
 * File:   PedidoEventual.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 1 de julio de 2022, 8:08
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "PedidoEventual.h"

PedidoEventual::PedidoEventual() {
    flete = 0;
}

PedidoEventual::PedidoEventual(const PedidoEventual& orig) {
}

PedidoEventual::~PedidoEventual() {
}

// ---------------------------------------------------------------------------

void PedidoEventual::SetFlete(double flete) {
    this->flete = flete;
}

double PedidoEventual::GetFlete() const {
    return flete;
}

// ---------------------------------------------------------------------------

void PedidoEventual::lee(ifstream& arch, int codigo, double descuento, double flete) {
    char c;
    
    arch >> this->flete >> c;
    Pedido::lee(arch, codigo, 0, this->flete);
}

// ---------------------------------------------------------------------------

void PedidoEventual::imprime(ofstream& arch) {
    Pedido::imprime(arch);
    arch << left << setw(15) << "Flete:" << right << setw(10) << flete << "%" << endl;
}
