/* 
 * Proyecto: LAB10_PREG01
 * File:   Pedido.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 1 de julio de 2022, 8:03
 */

#ifndef PEDIDO_H
#define PEDIDO_H

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

class Pedido {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    
    void SetTotal(double total);
    double GetTotal() const;
    void SetFecha(int fecha);
    int GetFecha() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void SetNombre(const char *cad);
    void GetNombre(char *cad) const;
    
    void cargarpedido(int codigo, char *nombre, int cantidad, int dni, int fecha, double total);
    
    virtual void lee(ifstream &arch, int codigo, double descuento, double flete);
    virtual void imprime(ofstream &arch);
    
    void imprimirfecha(ofstream &arch);
private:
    int codigo;
    char *nombre;
    int cantidad;
    int dni;
    int fecha;
    double total;
};

#endif /* PEDIDO_H */

