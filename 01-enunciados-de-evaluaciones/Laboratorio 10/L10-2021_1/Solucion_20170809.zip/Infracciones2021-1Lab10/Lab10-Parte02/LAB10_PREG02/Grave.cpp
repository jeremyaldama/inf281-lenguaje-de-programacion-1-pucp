/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Grave.cpp
 * Author: Alonso
 * 
 * Created on 9 de julio de 2021, 08:08 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
#include <cstring>
#include "Grave.h"

Grave::Grave() {
}

Grave::Grave(const Grave& orig) {
}

Grave::~Grave() {
}

void Grave::SetPuntos(int puntos) {
    this->puntos = puntos;
}

int Grave::GetPuntos() const {
    return puntos;
}

void Grave::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double Grave::GetDescuento() const {
    return descuento;
}

void Grave::leer(int codInfraccion) {
    ifstream archInfracciones("Infracciones.csv",ios::in);
    if(!archInfracciones){
        cout<<"ERROR: NO se puede abrir el archivo Infracciones.csv"<<endl;
        exit(1);
    }
    int codInfraccionArch,puntosAux;
    char aux[500];
    double monto,descuentoAux;
    while(1){
        archInfracciones>>codInfraccionArch;
        if(archInfracciones.eof()) break;
        if(codInfraccion==codInfraccionArch){
            archInfracciones.get();
            archInfracciones.getline(aux,500,','); //descripcion
            archInfracciones.getline(aux,500,','); //gravedad
            SetGravedad(aux);
            archInfracciones>>monto;
            SetMulta(monto);
            archInfracciones.get();
            
            archInfracciones>>descuentoAux;
            SetDescuento(descuentoAux);
            archInfracciones.get();
            archInfracciones>>puntosAux;
            SetPuntos(puntosAux);
        }
        else archInfracciones.getline(aux,500);
    }
}

void Grave::imprime(ofstream &archReporte) {
    char aux[100];
    int auxImprimir=0;
    GetGravedad(aux);
    archReporte<<left<<setw(15)<<aux<<right<<setw(10)<<GetMulta();
    archReporte<<setw(10)<<GetDescuento()<<setw(11)<<GetPuntos()<<setw(12)<<auxImprimir<<endl;
}