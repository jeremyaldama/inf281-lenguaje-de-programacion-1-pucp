/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Falta.cpp
 * Author: Alonso
 * 
 * Created on 9 de julio de 2021, 08:08 AM
 */

#include <cstring>
#include "Falta.h"

Falta::Falta() {
    placa=nullptr;
}

Falta::Falta(const Falta& orig) {
}

Falta::~Falta() {
}

void Falta::SetPlaca(char* aux) {
    if(placa!=nullptr) delete placa;
    placa=new char[strlen(aux)+1];
    strcpy(placa,aux);
}

void Falta::GetPlaca(char* aux) const {
    if(placa==nullptr) aux[0]=0;
    else strcpy(aux,placa);
}

void Falta::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Falta::GetFecha() const {
    return fecha;
}

void Falta::SetLicencia(int licencia) {
    this->licencia = licencia;
}

int Falta::GetLicencia() const {
    return licencia;
}

void Falta::operator=(Falta &falta) {
    fecha=falta.fecha;
    licencia=falta.licencia;
    SetPlaca(falta.placa);
}
