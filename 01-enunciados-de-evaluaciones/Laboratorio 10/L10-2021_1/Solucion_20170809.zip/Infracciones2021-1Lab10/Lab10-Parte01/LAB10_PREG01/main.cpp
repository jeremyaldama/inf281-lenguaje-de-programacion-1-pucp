/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 9 de julio de 2021, 08:07 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
#include "LFalta.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    LFalta lf1;
    
    lf1.leer("RegistroDeFaltas1.csv");
    lf1.imprimir("reporte.txt");

    return 0;
}

