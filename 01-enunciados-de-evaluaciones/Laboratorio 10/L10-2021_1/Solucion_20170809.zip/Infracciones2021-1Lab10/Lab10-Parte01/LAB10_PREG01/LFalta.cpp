/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   LFalta.cpp
 * Author: Alonso
 * 
 * Created on 9 de julio de 2021, 08:08 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
using namespace std;
#include "LFalta.h"
#include "NFalta.h"
#include "Leve.h"
#include "Grave.h"
#include "MuyGrave.h"

LFalta::LFalta() {
    lini=nullptr;
    lfin=nullptr;
}

LFalta::LFalta(const LFalta& orig) {
}

LFalta::~LFalta() {
    NFalta *ptActual, *ptAnterior;
    ptActual=lini;
    for(int i=0;ptActual;i++){
        ptAnterior=ptActual;
        ptActual=ptActual->sig;
        delete ptAnterior;
    }
}

void LFalta::leer(const char* nombArch) {
    ifstream archRegistroDeFaltas(nombArch,ios::in);
    if(!archRegistroDeFaltas){
        cout<<"ERROR: NO se puede abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    
    int codLicencia,codInfraccion,dd,mm,aa,fecha;
    char car,placa[100];
    
    Infraccion *infraccion;
    Falta falta;
    
    while(1){
        archRegistroDeFaltas>>codLicencia;
        if(archRegistroDeFaltas.eof()) break;
        archRegistroDeFaltas.get();
        archRegistroDeFaltas.getline(placa,100,',');
        archRegistroDeFaltas>>dd>>car>>mm>>car>>aa;
        archRegistroDeFaltas.get();
        archRegistroDeFaltas>>codInfraccion;
        
        fecha=aa*10000+mm*100+dd;
        
        falta.SetLicencia(codLicencia);
        falta.SetFecha(fecha);
        falta.SetPlaca(placa);
        
        if(codInfraccion/100==2){
            infraccion= new Leve;
        }
        else if(codInfraccion/100==1){
            infraccion= new Grave;
        }
        else if(codInfraccion/100==3){
            infraccion= new MuyGrave;
        }
        
        infraccion->SetCodigo(codInfraccion);
        infraccion->leer(codInfraccion);
        insertarLista(infraccion,falta);
    }
}

void LFalta::insertarLista(Infraccion *infraccion, Falta &falta) {
    NFalta *ptActual, *ptNuevo, *ptAnt=nullptr;
    ptNuevo= new NFalta;
    ptNuevo->dfalta=falta; //se está sobrecargando el =
    ptNuevo->pfalta=infraccion;
    ptNuevo->sig=nullptr;
    
    if(lini==nullptr){
        lini=ptNuevo;
        lfin=ptNuevo;
    }
    else{
        ptActual=lini;
        while(ptActual!=nullptr){
            if(ptNuevo->dfalta.GetFecha()<ptActual->dfalta.GetFecha()) break;
            ptAnt=ptActual;
            ptActual=ptActual->sig;
        }
        if(ptAnt==nullptr){
            ptNuevo->sig=lini;
            lini=ptNuevo;
        }
        else{
            if(ptActual==nullptr){
                lfin=ptNuevo;
                ptAnt->sig=ptNuevo;
            }
            else{
                ptNuevo->sig=ptActual;
                ptAnt->sig=ptNuevo;
            }
        }
    }
}

void LFalta::imprimir(const char* nombArch) {
    ofstream archReporte(nombArch,ios::out);
    if(!archReporte){
        cout<<"ERROR: NO se puede abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    
    archReporte.precision(2);
    archReporte<<fixed;
    
    NFalta *ptActual;
    ptActual=lini;
    char aux[100];
    int dd,mm,aa;
    
    for(int i=0;ptActual;i++){
        convertirFecha(dd,mm,aa,ptActual->dfalta.GetFecha());
        archReporte<<"Fecha: "<<right<<setfill('0')<<setw(4)<<aa<<"/"<<setw(2)<<mm<<"/"<<setw(2)<<dd<<endl<<setfill(' ');
        archReporte<<"Licencia: "<<ptActual->dfalta.GetLicencia()<<endl;
        ptActual->dfalta.GetPlaca(aux);
        archReporte<<"Placa: "<<aux<<endl;
        ptActual->pfalta->imprime(archReporte);
        ptActual=ptActual->sig;
        archReporte<<endl;
    }
}

void LFalta::convertirFecha(int &dd, int &mm, int &aa, int fecha) {
    aa=fecha/10000;
    fecha%=10000;
    mm=fecha/100;
    dd=fecha%100;
}

