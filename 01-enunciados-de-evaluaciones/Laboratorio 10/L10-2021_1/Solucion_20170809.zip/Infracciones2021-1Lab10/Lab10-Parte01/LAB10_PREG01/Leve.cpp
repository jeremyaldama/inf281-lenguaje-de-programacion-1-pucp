/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Leve.cpp
 * Author: Alonso
 * 
 * Created on 9 de julio de 2021, 08:08 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
#include <cstring>
#include "Leve.h"

Leve::Leve() {
}

Leve::Leve(const Leve& orig) {
}

Leve::~Leve() {
}

void Leve::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double Leve::GetDescuento() const {
    return descuento;
}

void Leve::leer(int codInfraccion) {
    ifstream archInfracciones("Infracciones.csv",ios::in);
    if(!archInfracciones){
        cout<<"ERROR: NO se puede abrir el archivo Infracciones.csv"<<endl;
        exit(1);
    }
    int codInfraccionArch;
    char aux[500];
    double monto,descuentoAux;
    while(1){
        archInfracciones>>codInfraccionArch;
        if(archInfracciones.eof()) break;
        if(codInfraccion==codInfraccionArch){
            archInfracciones.get();
            archInfracciones.getline(aux,500,','); //descripcion
            archInfracciones.getline(aux,500,','); //gravedad
            SetGravedad(aux);
            archInfracciones>>monto;
            SetMulta(monto);
            archInfracciones.get();
            
            archInfracciones>>descuentoAux;
            SetDescuento(descuentoAux);
        }
        else archInfracciones.getline(aux,500);
    }
}

void Leve::imprime(ofstream &archReporte) {
    char aux[100];
    archReporte<<"Codigo Infraccion: "<<GetCodigo()<<endl;
    GetGravedad(aux);
    archReporte<<"Gravedad: "<<aux<<endl;
    archReporte<<"Multa: "<<GetMulta()<<endl;
    
    archReporte<<"Descuento: "<<GetDescuento()<<endl;
}