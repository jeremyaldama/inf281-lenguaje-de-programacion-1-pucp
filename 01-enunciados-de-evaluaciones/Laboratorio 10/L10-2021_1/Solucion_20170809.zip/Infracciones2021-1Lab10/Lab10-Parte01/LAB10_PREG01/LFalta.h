/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   LFalta.h
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 9 de julio de 2021, 08:08 AM
 */

#ifndef LFALTA_H
#define LFALTA_H
#include "NFalta.h"
#include "Infraccion.h"
#include "Falta.h"

class LFalta {
private:
    NFalta *lini;
    NFalta *lfin;

public:
    LFalta();
    LFalta(const LFalta& orig);
    virtual ~LFalta();
    
    void leer(const char *nombArch);
    void imprimir(const char *nombArch);
    void insertarLista(Infraccion *, Falta &);
    void convertirFecha(int &, int &,int &, int);
};

#endif /* LFALTA_H */

