/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NFalta.cpp
 * Author: Alonso
 * 
 * Created on 9 de julio de 2021, 08:08 AM
 */

#include "NFalta.h"

NFalta::NFalta() {
    pfalta=nullptr;
    sig=nullptr;
}

NFalta::NFalta(const NFalta& orig) {
}

NFalta::~NFalta() {
    //delete pfalta;
}

