/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Grave.h
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 9 de julio de 2021, 08:08 AM
 */

#ifndef GRAVE_H
#define GRAVE_H
#include "Infraccion.h"
#include <fstream>
using namespace std;

class Grave : public Infraccion{
private:
    double descuento;
    int puntos;

public:
    Grave();
    Grave(const Grave& orig);
    virtual ~Grave();
    void SetPuntos(int puntos);
    int GetPuntos() const;
    void SetDescuento(double descuento);
    double GetDescuento() const;
    
    void leer(int);
    void imprime(ofstream &);
};

#endif /* GRAVE_H */

