/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Infraccion.cpp
 * Author: Alonso
 * 
 * Created on 9 de julio de 2021, 08:08 AM
 */

#include <cstring>
#include "Infraccion.h"

Infraccion::Infraccion() {
    gravedad=nullptr;
}

Infraccion::Infraccion(const Infraccion& orig) {
}

Infraccion::~Infraccion() {
    delete gravedad;
}

void Infraccion::SetMulta(double multa) {
    this->multa = multa;
}

double Infraccion::GetMulta() const {
    return multa;
}

void Infraccion::SetGravedad(char *aux) {
    if(gravedad!=nullptr) delete gravedad;
    gravedad=new char[strlen(aux)+1];
    strcpy(gravedad,aux);
}

void Infraccion::GetGravedad(char *aux) const {
    if(gravedad==nullptr) aux[0]=0;
    else strcpy(aux,gravedad);
}

void Infraccion::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Infraccion::GetCodigo() const {
    return codigo;
}

