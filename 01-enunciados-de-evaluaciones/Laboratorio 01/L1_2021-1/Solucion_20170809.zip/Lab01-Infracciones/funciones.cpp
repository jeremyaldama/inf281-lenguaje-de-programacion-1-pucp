/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * 
 */

#include <iostream>
#include <iomanip>
using namespace std;
#include "funciones.h"
#define MAX_LINEA 200

void emitirReporte(){
    int licConductor,cantMultasLeves,cantMultasGraves,cantMultasMuyGraves;
    double montoMultasLeves,montoMultasGraves,montoMultasMuyGraves;
    int puntosMultasLeves,puntosMultasGraves,puntosMultasMuyGraves;
    char nombre[100];
    cout<<setw(100)<<"REGULADORA DE TRANSPORTE URBANO"<<endl;
    cin>>licConductor;
    if(cin.eof()) return;
    
    cout.precision(2);
    cout<<fixed;
    
    while(1){
        cin>>nombre;
        if(cin.eof()) break;
        imprimirEncabezado();
        cantMultasLeves=0;
        cantMultasGraves=0;
        cantMultasMuyGraves=0;
        montoMultasLeves=0.0;
        montoMultasGraves=0.0;
        montoMultasMuyGraves=0.0;
        puntosMultasLeves=0;
        puntosMultasGraves=0;
        puntosMultasMuyGraves=0;
        leerInfracciones(licConductor,cantMultasLeves,cantMultasGraves,cantMultasMuyGraves,montoMultasLeves,montoMultasGraves,montoMultasMuyGraves,
                puntosMultasLeves,puntosMultasGraves,puntosMultasMuyGraves,nombre);
        imprimirLinea('=',MAX_LINEA);
        imprimirResumen(cantMultasLeves,cantMultasGraves,cantMultasMuyGraves,montoMultasLeves,montoMultasGraves,montoMultasMuyGraves,
                puntosMultasLeves,puntosMultasGraves,puntosMultasMuyGraves);
    }
}

void imprimirEncabezado(){
    imprimirLinea('=',MAX_LINEA);
    cout<<setw(27)<<"CONDUCTOR"<<setw(88)<<"INFRACCIONES"<<endl;
    imprimirLinea('-',MAX_LINEA);
    cout<<"Licencia No."<<setw(6)<<" "<<"Nombre"<<setw(49)<<"Placa"<<setw(15)<<"Fecha"<<setw(15)<<"Codigo"<<setw(15)<<"Gravedad"<<setw(15)<<"Puntos"<<setw(10)<<"Multa"<<endl;
    imprimirLinea('-',MAX_LINEA);
}

void imprimirLinea(char car,int cant){
    for(int i=0;i<cant;i++){
        cout<<car;
    }
    cout<<endl;
}

void leerInfracciones(int &licConductor,int &cantMultasLeves,int &cantMultasGraves,int &cantMultasMuyGraves,double &montoMultasLeves,double &montoMultasGraves,double &montoMultasMuyGraves,
        int &puntosMultasLeves,int &puntosMultasGraves,int &puntosMultasMuyGraves,char *nombre){
    int aux,dd,mm,aa,cantFecha,licConductorAux,codInfraccion,i=0;
    char placa[20],palabraMulta[20],gravedad;
    double montoMulta;
    while(1){
        cin>>aux; //Intentamos leer el numero de lic de otro conductor
        if(cin.eof()) break;
        if(cin.fail()){ //Si falla estamos leyendo una infraccion de la misma persona
            cin.clear();
            cin>>placa;
            leerFecha(dd,mm,aa,cantFecha);
            cin>>gravedad>>codInfraccion>>palabraMulta>>montoMulta;
            if(gravedad=='L'){
                cantMultasLeves++;
                montoMultasLeves+=montoMulta;
                puntosMultasLeves+=5;
            }
            else if(gravedad=='G'){
                cantMultasGraves++;
                montoMultasGraves+=montoMulta;
                puntosMultasGraves+=70;
            }
            else if(gravedad=='M'){
                cantMultasMuyGraves++;
                montoMultasMuyGraves+=montoMulta;
                puntosMultasMuyGraves+=150;
            }
            licConductorAux=licConductor;
            if(i==0){
                cout<<setw(8)<<licConductorAux<<setw(10)<<" "<<left<<setw(50)<<nombre<<right;
            }
            else{
                cout<<setw(68)<<" "<<right;
            }
            imprimirInfraccion(placa,dd,mm,aa,cantFecha,codInfraccion,gravedad,montoMulta);
            i++;
        }
        else{ //Cambiamos de persona
            licConductor=aux;
            break;
        }
    }
}

void imprimirInfraccion(char *placa,int dd,int mm,int aa,int cantFecha,int codInfraccion,char gravedad,double montoMulta){
    cout<<setw(7)<<placa<<setw(6)<<" ";
    if(cantFecha==3){
        cout<<setfill('0')<<setw(2)<<dd<<"/"<<setw(2)<<mm<<"/"<<setw(4)<<aa;
    }
    else if(cantFecha==2){
        cout<<setfill('0')<<setw(2)<<"--"<<"/"<<setw(2)<<mm<<"/"<<setw(4)<<aa;
    }
    else if(cantFecha==1){
        cout<<setfill('0')<<setw(2)<<"--"<<"/"<<setw(2)<<"--"<<"/"<<setw(4)<<aa;
    }
    cout<<setfill(' ')<<setw(10)<<codInfraccion<<setw(10)<<" "<<left;
    if(gravedad=='L'){
        cout<<setw(14)<<"Leve"<<right<<setw(7)<<"5";
    }
    else if(gravedad=='G'){
        cout<<setw(14)<<"Grave"<<right<<setw(7)<<"70";
    }
    else if(gravedad=='M'){
        cout<<setw(14)<<"Muy Grave"<<right<<setw(7)<<"150";
    }
    cout<<setw(12)<<montoMulta<<endl;
}

void leerFecha(int &dd,int &mm,int &aa,int &cantFecha){
    int aaAux,mmAux;
    cin>>aaAux; //leemos un posible año, por lo menos hay un año
    cin>>mmAux; //Intentamos leer un mes
    if(cin.fail()){ //Si falla es porque solo está el año y leyó el cod de la infraccion
        cin.clear();
        aa=aaAux;
        mm=0;
        dd=0;
        cantFecha=1;
        return;
    }
    else{ //Si no falla, es formato mm aa o dd mm aa
        if(mmAux>1000){ //Leimos un año
            mm=aaAux;
            aa=mmAux;
            dd=0;
            cantFecha=2;
        }
        else{ //Leimos un mes
            dd=aaAux;
            mm=mmAux;
            cin>>aaAux;
            aa=aaAux;
            cantFecha=3;
        }
    }
}

void imprimirResumen(int cantMultasLeves,int cantMultasGraves,int cantMultasMuyGraves,double montoMultasLeves,double montoMultasGraves,double montoMultasMuyGraves,
        int puntosMultasLeves,int puntosMultasGraves,int puntosMultasMuyGraves){
    int cantTotal,puntosTotal;
    double montoTotal;
    cantTotal=cantMultasLeves+cantMultasGraves+cantMultasMuyGraves;
    montoTotal=montoMultasLeves+montoMultasGraves+montoMultasMuyGraves;
    puntosTotal=puntosMultasLeves+puntosMultasGraves+puntosMultasMuyGraves;
    cout<<"RESUMEN:"<<endl;
    cout<<"Gravedad"<<setw(39)<<"Cantidad"<<setw(21)<<"Multas pagadas"<<setw(19)<<"Puntos perdidos"<<endl;
    cout<<left<<setw(40)<<"Multas leves:"<<right<<setw(3)<<cantMultasLeves<<setw(20)<<montoMultasLeves<<setw(16)<<puntosMultasLeves<<endl;
    cout<<left<<setw(40)<<"Multas graves:"<<right<<setw(3)<<cantMultasGraves<<setw(20)<<montoMultasGraves<<setw(16)<<puntosMultasGraves<<endl;
    cout<<left<<setw(40)<<"Multas muy graves:"<<right<<setw(3)<<cantMultasMuyGraves<<setw(20)<<montoMultasMuyGraves<<setw(16)<<puntosMultasMuyGraves<<endl;
    imprimirLinea('-',MAX_LINEA);
    cout<<"TOTAL:"<<setw(37)<<cantTotal<<setw(20)<<montoTotal<<setw(16)<<puntosTotal<<endl;
    imprimirLinea('=',MAX_LINEA);
    imprimirLinea('/',MAX_LINEA);
}