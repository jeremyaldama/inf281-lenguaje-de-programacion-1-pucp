/* 
 * Proyecto: 2022-1_Lab5_MetodoDeIncrementos
 * File:   MetodoPorIncrementos.cpp
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 13 de mayo de 2022, 8:05
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
using namespace std;

#define MAX_CAR 150
#define INCREMENTO 5

#include "MetodoPorIncrementos.h"
#include "Clientes.h"

void imprimirLinea(ofstream &archRep, char car){
    for (int i = 0; i < MAX_CAR; i++) archRep.put(car);
    archRep << endl;
}

char * leePalabra(ifstream &arch, char car) {
    char buff[500], *cad;
    arch.getline(buff, 500, car);
    if (arch.eof()) return nullptr;
    cad = new char [strlen(buff) + 1];
    strcpy(cad, buff);
    return cad;
}

ifstream abrirArchL(const char *nombre) {
    ifstream arch;
    arch.open(nombre, ios::in);
    if (!arch) {
        cout << "ERROR: no se pudo abrir el archivo " << nombre << endl;
        exit(1);
    }
    return arch;
}

ofstream abrirArchE(const char *nombre) {
    ofstream arch;
    arch.open(nombre, ios::out);
    if (!arch) {
        cout << "ERROR: no se pudo abrir el archivo " << nombre << endl;
        exit(1);
    }
    arch << setprecision(2) << fixed;
    return arch;
}

void dmatof(int dd, int mm, int aa, int &fecha){
    fecha = aa*10000 + mm*100 +dd;
}

void imprimeFecha(ofstream &arch, int fecha){
    int dd, mm, aa;
    dd = fecha%100;
    fecha /= 100;
    mm = fecha%100;
    aa = fecha/100;
    arch << right << setfill('0') << setw(2) << dd << "/" << 
            setw(2) << mm << "/" 
            << setw(4) << left << aa << setfill(' ');
}

//--------------------------------------------------------------------------------

void inicializarPtr(char ***&ped_Codigo,  int ***&ped_FechaCantidad, int numDat){
    ped_Codigo = new char **[numDat + 1];
    ped_FechaCantidad = new int **[numDat + 1];
    
    for(int i=0; i<numDat; i++){
        ped_Codigo[i] = nullptr;
        ped_FechaCantidad[i] = nullptr;
    }
}

int contarDatos(int **cli_DniTelefono){
    int i = 0;
    while (cli_DniTelefono[i]) i++;
    return i;
}

void leerDatos(ifstream &arch, char *&descrip, double &desc, int &cant, double &precUni, int &dniCli, int &fecha){
    char car;
    int dd, mm, aa;
    descrip = leePalabra(arch, ',');
    arch >> cant;
    if(arch.fail()){
        arch.clear();
        arch.get();
        arch >> desc >> car >> cant >> car;
    }else{
        desc = 0;
        arch.get();
    }
    arch >> precUni >> car >> dniCli >> car >> dd >> car >> mm >> car >> aa;
    arch.get();
    dmatof(dd, mm, aa, fecha);
}

void CargaDePedidosYProductos(int **cli_DniTelefono, char ***&pro_CodigoDescripcion,
        double **&pro_PrecioDescuento, char ***&ped_Codigo,  int ***&ped_FechaCantidad, const char *nombre){
    ifstream arch = abrirArchL(nombre);
    
    int nd[1000]{}, tam[1000]{}, numProd = 0, tamProd=0;
    
    int numCli = contarDatos(cli_DniTelefono);
    inicializarPtr(ped_Codigo, ped_FechaCantidad, numCli);
    
    int dniCli, fecha, cant;
    char *descrip, *ped;
    double desc, precUni;
    
    pro_CodigoDescripcion = nullptr;
    pro_PrecioDescuento = nullptr;
    
    while (1) {
        ped = leePalabra(arch, ',');
        if (ped == nullptr) break;
        
        leerDatos(arch, descrip, desc, cant, precUni, dniCli, fecha);
        
        int posCli = buscarCliente(cli_DniTelefono, dniCli);
        if (posCli != -1){
            agregarUnitario(ped_Codigo[posCli], ped_FechaCantidad[posCli], tam[posCli], nd[posCli], ped, fecha, cant);
        }
        int posProd = buscarCodigo(pro_CodigoDescripcion, ped);
        if(posProd == -1){
            agregarProducto(pro_CodigoDescripcion, pro_PrecioDescuento, ped, descrip, desc, precUni, numProd, tamProd);
        }
    }
}

int buscarCodigo(char ***pro_CodigoDescripcion, char *cod){
    if(pro_CodigoDescripcion == nullptr){
        return -1;
    }
    
    for(int i=0; pro_CodigoDescripcion[i]; i++){
        if(strcmp(pro_CodigoDescripcion[i][0], cod) == 0){
            return i;
        }
    }
    return -1;
}

void agregarProducto(char ***&pro_CodigoDescripcion, double **&pro_PrecioDescuento, char *ped, char *descrip, double desc, double precUni, int &nd, int &tam){
    double *aux1;
    aux1 = new double [2];
    aux1[0] = precUni;
    aux1[1] = desc;
    
    char **aux2;
    aux2 = new char *[2];
    aux2[0] = ped;
    aux2[1] = descrip;
    
    if (nd == tam){
        incrementarEspacios1(pro_CodigoDescripcion, pro_PrecioDescuento, tam, nd);
    }
    pro_CodigoDescripcion[nd] = nullptr;
    pro_CodigoDescripcion[nd - 1] = aux2;
    pro_PrecioDescuento[nd] = nullptr;
    pro_PrecioDescuento[nd - 1] = aux1;
    nd++;
}

void incrementarEspacios1(char ***&pro_CodigoDescripcion, double **&pro_PrecioDescuento, int &tam, int &nd){
    char ***auxC;
    double **auxP;
    
    tam += INCREMENTO;
    if (pro_CodigoDescripcion == nullptr) {
        pro_CodigoDescripcion = new char **[tam];
        pro_PrecioDescuento = new double *[tam];
        
        pro_CodigoDescripcion[0] = nullptr;
        pro_PrecioDescuento[0] = nullptr;
        
        nd = 1;
    } else {
        auxC = new char **[tam];
        auxP = new double *[tam];
        
        for (int i = 0; i < nd; i++){
            auxC[i] = pro_CodigoDescripcion[i];
            auxP[i] = pro_PrecioDescuento[i];
        }
        
        delete pro_CodigoDescripcion;
        delete pro_PrecioDescuento;
        pro_CodigoDescripcion = auxC;
        pro_PrecioDescuento = auxP;
    }
}

void agregarUnitario(char **&ped_Codigo,  int **&ped_FechaCantidad, int &tam, int &nd, char *ped, int fecha, int cant){
    int *aux1;
    aux1 = new int [2];
    aux1[0] = fecha;
    aux1[1] = cant;
    
    if (nd == tam){
        incrementarEspacios(ped_Codigo, ped_FechaCantidad, tam, nd);
    }
    ped_Codigo[nd] = nullptr;
    ped_Codigo[nd - 1] = ped;
    ped_FechaCantidad[nd] = nullptr;
    ped_FechaCantidad[nd - 1] = aux1;
    nd++;
}

void incrementarEspacios(char **&ped_Codigo,  int **&ped_FechaCantidad, int &tam, int &nd){
    char **auxC;
    int **auxF;
    
    tam += INCREMENTO;
    if (ped_Codigo == nullptr) {
        ped_Codigo = new char *[tam];
        ped_FechaCantidad = new int *[tam];
        
        ped_Codigo[0] = nullptr;
        ped_FechaCantidad[0] = nullptr;
        
        nd = 1;
    } else {
        auxC = new char *[tam];
        auxF = new int *[tam];
        
        for (int i = 0; i < nd; i++){
            auxC[i] = ped_Codigo[i];
            auxF[i] = ped_FechaCantidad[i];
        }
        
        delete ped_Codigo;
        delete ped_FechaCantidad;
        ped_Codigo = auxC;
        ped_FechaCantidad = auxF;
    }
}

int buscarCliente(int **cli_DniTelefono, int dniCli){
    for(int i=0; cli_DniTelefono[i]; i++){
        if(cli_DniTelefono[i][0] == dniCli){
            return i;
        }
    }
    return -1;
}

void ReporteDePedidosYProductos(int **cli_DniTelefono, char ***pro_CodigoDescripcion,
        double **pro_PrecioDescuento, char ***ped_Codigo, int ***ped_FechaCantidad,
        const char *nombre){
    ofstream arch = abrirArchE(nombre);
    
    arch << left << "REPORTE PEDIDOS" << endl;
    imprimirLinea(arch, '=');
    for(int i=0; cli_DniTelefono[i]; i++){
        arch << setw(15) << "DNI COMPRADOR: " << setw(10) << cli_DniTelefono[i][0] << setw(10) << cli_DniTelefono[i][1] << endl;
        imprimirLinea(arch, '-');
        arch << right << setw(8) << "CODPROD" << setw(15) << "FECHA" << setw(15) << "CANTIDAD" << endl;
        if(ped_Codigo[i]){
            imprimirPedidos(arch, ped_Codigo[i], ped_FechaCantidad[i]);
        }
        arch << endl;
    }
    
    arch << endl << endl;
    imprimirLinea(arch, '*');
    arch << left << "REPORTE PRODUCTOS" << endl;
    imprimirLinea(arch, '*');
    arch << left << setw(75) << "COD PRODUCTO: " << setw(10) << "PRECIO" <<
            setw(15) << "DESCUENTO" << endl;
    for(int i=0; pro_CodigoDescripcion[i]; i++){
        arch << right << setw(3) << i + 1 << ")  ";
        arch << left << setw(15) << pro_CodigoDescripcion[i][0] << 
                setw(50) << pro_CodigoDescripcion[i][1] <<
                right << setw(10) << pro_PrecioDescuento[i][0] <<
                setw(10) << pro_PrecioDescuento[i][1] << endl;
    }
}

void imprimirPedidos(ofstream &arch, char **ped_Codigo, int **ped_FechaCantidad){
    if(ped_FechaCantidad){
        for(int i=0; ped_FechaCantidad[i]; i++){
            arch << right << setw(3) << i + 1 << ")  ";
            arch << setw(10) << ped_Codigo[i] << "  ";
//            arch << setw(10) << ped_FechaCantidad[i][0];
            imprimeFecha(arch, ped_FechaCantidad[i][0]);
            arch << "   " << setw(10) << ped_FechaCantidad[i][1];
            arch << endl;
        }
    }
}

void ReporteRlacionDePedidos(int **cli_DniTelefono, char ***cli_NombreCategoria, 
        char ***pro_CodigoDescripcion, double **pro_PrecioDescuento, char ***ped_Codigo, 
        int ***ped_FechaCantidad, const char *nombre){
    ofstream arch = abrirArchE(nombre);
    imprimirCabeceraReporte(arch);
    for(int i=0; cli_DniTelefono[i]; i++){
        imprimirLinea(arch, '=');
        arch << left << setw(15) << "DNI" << setw(50) << "Nombre" << setw(15) <<
                "Categoria" << "Telefono" << endl;
        arch << setw(15) << cli_DniTelefono[i][0] << setw(50) << cli_NombreCategoria[i][0] << 
                setw(15) << cli_NombreCategoria[i][1] << cli_DniTelefono[i][1] << endl;
        imprimirLinea(arch, '-');
        arch << "PRODUCTOS ADQUIRIDOS" << endl;
        imprimirLinea(arch, '-');
        arch<<setw(5)<<"     " <<
                setw(10)<<"Codigo"<<
                setw(55)<<"Descripcion"<<
                setw(8)<<"P.U."<<
                setw(11)<<"Cantidad"<<
                setw(8)<<"Total"<<
                setw(12)<<"Descuento %"<<
                setw(10)<<"A Pagar"<<
                setw(13)<<"Descuento"<<
                setw(10)<<"Fecha"<<endl;
        imprimirLinea(arch, '-');
        imprimirProductos(arch, ped_Codigo[i], ped_FechaCantidad[i], pro_CodigoDescripcion, pro_PrecioDescuento);
        imprimirLinea(arch, '-');
    }
}

void imprimirProductos(ofstream &arch, char **ped_Codigo, 
        int **ped_FechaCantidad, char ***pro_CodigoDescripcion, double **pro_PrecioDescuento){
    if(ped_FechaCantidad){ // No null
        double total, pagar;
        double TOtalPagar = 0, totalDescuento=0;
        for(int i=0; ped_Codigo[i]; i++){
            arch << right << setw(3) << i + 1 << ")  ";
            arch << left << setw(10) << ped_Codigo[i];
            int pos = buscarCodigo(pro_CodigoDescripcion, ped_Codigo[i]);
            arch << setw(50) << pro_CodigoDescripcion[pos][1] << right <<
                    setw(10) << pro_PrecioDescuento[pos][0] << 
                    setw(10) << ped_FechaCantidad[i][1];
            total = pro_PrecioDescuento[pos][0] * ped_FechaCantidad[i][1];
            arch << setw(10) << total << 
                    setw(10) << pro_PrecioDescuento[pos][1];
            pagar = total * (1-pro_PrecioDescuento[pos][1]/100);
            arch << setw(10) << pagar <<
                    setw(10) << total * (pro_PrecioDescuento[pos][1]/100) << "  ";
            totalDescuento +=  total * (pro_PrecioDescuento[pos][1]/100);
//            arch << setw(10) << ped_FechaCantidad[i][0] << endl;
            imprimeFecha(arch, ped_FechaCantidad[i][0]);
            arch << endl;
            TOtalPagar += pagar;
        }
        imprimirLinea(arch, '-');
        arch << setw(106) << "TOTAL" << setw(10) << TOtalPagar << setw(10) << totalDescuento << endl;
    }
}

void imprimirCabeceraReporte(ofstream &arch){
    arch << left << setw(20) << " " << "EMPRESA COMERCIALIZADORA DE ABARROTES" << endl;
    imprimirLinea(arch, '=');
    arch << "GASTOS DE LOS CLIENTES REGISTRADOS:" << endl;
}