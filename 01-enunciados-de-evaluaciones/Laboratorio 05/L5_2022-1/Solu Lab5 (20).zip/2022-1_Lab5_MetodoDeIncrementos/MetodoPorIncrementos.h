/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * Proyecto: 2022-1_Lab5_MetodoDeIncrementos
 * File:   MetodoPorIncrementos.h
 * Author: Gianella Lilian Lope Sainz
 * Código: 20191408
 * Created on 13 de mayo de 2022, 8:05
 */

#ifndef METODOPORINCREMENTOS_H
#define METODOPORINCREMENTOS_H

#include <fstream>
using namespace std;

void imprimirLinea(ofstream &archRep, char car);
char * leePalabra(ifstream &arch, char car='\n');
ifstream abrirArchL(const char *nombre);
ofstream abrirArchE(const char *nombre);
void dmatof(int dd, int mm, int aa, int &fecha);
void imprimeFecha(ofstream &arch, int fecha);

void inicializarPtr(char ***&ped_Codigo,  int ***&ped_FechaCantidad, int numDat);
int contarDatos(int **cli_DniTelefono);
void leerDatos(ifstream &arch, char *&descrip, double &desc, int &cant, double &precUni, int &dniCli, int &fecha);
void CargaDePedidosYProductos(int **cli_DniTelefono, char ***&pro_CodigoDescripcion,
        double **&pro_PrecioDescuento, char ***&ped_Codigo,  int ***&ped_FechaCantidad, const char *nombre);

void agregarUnitario(char **&ped_Codigo,  int **&ped_FechaCantidad, int &tam, int &nd, char *ped, int fecha, int cant);
void incrementarEspacios(char **&ped_Codigo,  int **&ped_FechaCantidad, int &tam, int &nd);
int buscarCliente(int **cli_DniTelefono, int dniCli);
void ReporteDePedidosYProductos(int **cli_DniTelefono, char ***pro_CodigoDescripcion,
        double **pro_PrecioDescuento, char ***ped_Codigo, int ***ped_FechaCantidad,
        const char *nombre);
void imprimirPedidos(ofstream &arch, char **ped_Codigo, int **ped_FechaCantidad);
void imprimeFechaCantidad(ofstream &arch,int *ped_FechaCantidad);

int buscarCodigo(char ***pro_CodigoDescripcion, char *cod);
void agregarProducto(char ***&pro_CodigoDescripcion, double **&pro_PrecioDescuento, char *ped, char *descrip, double desc, double precUni, int &nd, int &tam);
void incrementarEspacios1(char ***&pro_CodigoDescripcion, double **&pro_PrecioDescuento, int &tam, int &nd);

void ReporteRlacionDePedidos(int **cli_DniTelefono, char ***cli_NombreCategoria, 
        char ***pro_CodigoDescripcion, double **pro_PrecioDescuento, char ***ped_Codigo, 
        int ***ped_FechaCantidad, const char *nombre);
void imprimirCabeceraReporte(ofstream &arch);
void imprimirProductos(ofstream &arch, char **ped_Codigo, 
        int **ped_FechaCantidad, char ***pro_CodigoDescripcion, double **pro_PrecioDescuento);


#endif /* METODOPORINCREMENTOS_H */
