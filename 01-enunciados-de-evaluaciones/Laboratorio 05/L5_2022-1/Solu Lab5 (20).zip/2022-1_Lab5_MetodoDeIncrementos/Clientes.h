/* 
 * Proyecto: ClientesBib
 * Archivo:  Clientes.h
 * Autor:    J. Miguel Guanira E.
 *
 * Created on 11 de mayo de 2022, 07:12 PM
 */

#ifndef CLIENTES_H
#define CLIENTES_H

void CargaDeClientes (int **&, char***&, const char*);
void ReporteDeClientes(int **,char ***,const char*);

#endif /* CLIENTES_H */

