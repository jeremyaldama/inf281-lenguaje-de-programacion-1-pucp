/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 7 de mayo de 2021, 08:02 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
#include "BibliotecaMemoriaDinamica.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    char **conductor,*gravedad;
    int *licencia,*infraccion;
    double *multa;
    
    cargarConductores(licencia,conductor);
    reporteConductores(licencia,conductor);
    cargarInfracciones(infraccion,gravedad,multa);
    reporteInfracciones(infraccion,gravedad,multa);
    reporteDeFaltas(licencia,conductor,infraccion,gravedad,multa);

    return 0;
}

