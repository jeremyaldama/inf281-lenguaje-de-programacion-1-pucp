/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
using namespace std;
#include "BibliotecaMemoriaDinamica.h"
#define MAX_LINEA 200

void cargarConductores(int *&licencia,char **&conductor){
    ifstream archConductores("Conductores.csv",ios::in);
    if(!archConductores){
        cout<<"ERROR: NO se pudo abrir el archivo Conductores.csv"<<endl;
        exit(1);
    }
    
    int licenciaAux[200],numConductores=0;
    char *conductorAux[200];
    
    while(1){
        archConductores>>licenciaAux[numConductores];
        if(archConductores.eof()) break;
        archConductores.get();
        conductorAux[numConductores]=leerNombreConductor(archConductores);
        numConductores++;
    }
    
    licenciaAux[numConductores]=-1;
    conductorAux[numConductores]=nullptr;
    
    licencia=new int[numConductores+1];
    conductor=new char*[numConductores+1];
    
    for(int i=0;i<numConductores+1;i++){
        licencia[i]=licenciaAux[i];
        conductor[i]=conductorAux[i];
    }
}

char * leerNombreConductor(ifstream &archConductores){
    char aux[200],*ptAux;
    archConductores.getline(aux,200);
    ptAux=new char[strlen(aux)+1];
    strcpy(ptAux,aux);
    return ptAux;
}

void reporteConductores(int *licencia,char **conductor){
    ofstream archMuestraConductores("MuestraConductores.txt",ios::out);
    if(!archMuestraConductores){
        cout<<"ERROR: NO se pudo abrir el archivo MuestraConductores.txt"<<endl;
        exit(1);
    }
    
    archMuestraConductores<<"Licencia"<<setw(13)<<"Conductor"<<endl;
    for(int i=0;conductor[i];i++){
        archMuestraConductores<<right<<licencia[i]<<setw(4)<<" "<<left<<setw(50)<<conductor[i]<<endl;
    }
    
}

void cargarInfracciones(int *&infraccion,char *&gravedad,double *&multa){
    ifstream archInfracciones("Infracciones.csv",ios::in);
    if(!archInfracciones){
        cout<<"ERROR: NO se pudo abrir el archivo Infracciones.csv"<<endl;
        exit(1);
    }
    
    int infraccionesAux[500],numInfracciones=0;
    char descripcion[500],gravedadAux[500];
    double multaAux[500];
    
    while(1){
        archInfracciones>>infraccionesAux[numInfracciones];
        if(archInfracciones.eof()) break;
        archInfracciones.get();
        archInfracciones.getline(descripcion,500,',');
        gravedadAux[numInfracciones]=leerGravedad(archInfracciones);
        archInfracciones>>multaAux[numInfracciones];
        numInfracciones++;
    }
    
    infraccionesAux[numInfracciones]=-1;
    gravedadAux[numInfracciones]=-1;
    multaAux[numInfracciones]=-1;
    
    infraccion=new int[numInfracciones+1];
    gravedad=new char[numInfracciones+1];
    multa=new double[numInfracciones+1];
    
    for(int i=0;i<numInfracciones+1;i++){
        infraccion[i]=infraccionesAux[i];
        gravedad[i]=gravedadAux[i];
        multa[i]=multaAux[i];
    }
    
}

char leerGravedad(ifstream &archInfracciones){
    char aux[50];
    archInfracciones.getline(aux,50,',');
    return aux[0];
}

void reporteInfracciones(int *infraccion,char *gravedad,double *multa){
    
    ofstream archMuestraInfracciones("MuestraInfracciones.txt",ios::out);
    if(!archMuestraInfracciones){
        cout<<"ERROR: NO se pudo abrir el archivo MuestraInfracciones.txt"<<endl;
        exit(1);
    }
    
    archMuestraInfracciones.precision(2);
    archMuestraInfracciones<<fixed;
    
    archMuestraInfracciones<<"Infraccion"<<setw(12)<<"Gravedad"<<setw(10)<<"Multa"<<endl;
    for(int i=0;infraccion[i]!=-1;i++){
        archMuestraInfracciones<<infraccion[i]<<setw(15)<<gravedad[i]<<setw(15)<<multa[i]<<endl;
    }
    
}

void reporteDeFaltas(int *licencia,char **conductor,int *infraccion,char *gravedad,double *multa){
       
    ofstream archReporte("Reporte.txt",ios::out);
    if(!archReporte){
        cout<<"ERROR: NO se pudo abrir el archivo Reporte.txt"<<endl;
        exit(1);
    }
    
    archReporte.precision(2);
    archReporte<<fixed;
    
    int *licenciaRep,*cantidad,i=0;
    char **placa,car;
    double *monto;
    
    while(1){
        if(i==0) car='L';
        else if(i==1) car='G';
        else if(i==2) car='M';
        else break;
        leerArchivo(licenciaRep,cantidad,placa,monto,infraccion,gravedad,multa,car);
        imprimirReporte(licenciaRep,cantidad,placa,monto,archReporte,car);
        liberarMemoria(licenciaRep,cantidad,placa,monto);
        i++;
    }
    
}

void leerArchivo(int *&licenciaRep,int *&cantidad,char **&placa,double *&monto,int *infraccion,char *gravedad,double *multa,char car){
    ifstream archRegistroDeFaltas("RegistroDeFaltas.csv",ios::in);
    if(!archRegistroDeFaltas){
        cout<<"ERROR: NO se pudo abrir el archivo RegistroDeFaltas.csv"<<endl;
        exit(1);
    }
    
    int licenciaArch,infraccionArch,posInfraccion,posPlaca,numPlacas=0;
    char placaArch[50];
    
    int licenciaAux[1000],cantidadAux[1000]={0}; //Se inicializa los arreglos donde sea acumulan datos en 0
    char *placaAux[1000],fecha[50];
    double montoAux[1000]={0};
    
    while(1){
        archRegistroDeFaltas>>licenciaArch;
        if(archRegistroDeFaltas.eof()) break;
        archRegistroDeFaltas.get();
        archRegistroDeFaltas.getline(placaArch,50,',');
        archRegistroDeFaltas.getline(fecha,50,',');
        archRegistroDeFaltas>>infraccionArch;
        posInfraccion=buscarInfraccion(infraccion,infraccionArch);
        if(gravedad[posInfraccion]==car){
            posPlaca=buscaPlaca(placaAux,numPlacas,placaArch);
            if(posPlaca!=-1){//Encontro la placa
                cantidadAux[posPlaca]++; //Acumulamos en esa posicion
                montoAux[posPlaca]+=multa[posInfraccion]; //Acumulamos en esa posicion
            }
            else{ //Si no existe la placa se agrega al final del arreglo
                licenciaAux[numPlacas]=licenciaArch;
                placaAux[numPlacas]=leerPlaca(placaArch);
                cantidadAux[numPlacas]++;
                montoAux[numPlacas]+=multa[posInfraccion];
                numPlacas++;
            }
        }
        
    }
    
    licenciaAux[numPlacas]=-1;
    cantidadAux[numPlacas]=-1;
    placaAux[numPlacas]=nullptr;
    montoAux[numPlacas]=-1;
    
    licenciaRep=new int[numPlacas+1];
    cantidad=new int[numPlacas+1];
    placa=new char*[numPlacas+1];
    monto=new double[numPlacas+1];
    
    for(int i=0;i<numPlacas+1;i++){
        licenciaRep[i]=licenciaAux[i];
        cantidad[i]=cantidadAux[i];
        placa[i]=placaAux[i];
        monto[i]=montoAux[i];
    }
    
}

char * leerPlaca(char *placaArch){
    char *ptAux;
    ptAux=new char[strlen(placaArch)+1];
    strcpy(ptAux,placaArch);
    return ptAux;
}

int buscarInfraccion(int *infraccion,int infraccionArch){
    for(int i=0;infraccion[i]!=-1;i++){
        if(infraccion[i]==infraccionArch) return i;
    }
    return -1;
}

int buscaPlaca(char **placaAux,int numPlacas,char *placaArch){
    for(int i=0;i<numPlacas;i++){
        if(strcmp(placaAux[i],placaArch)==0) return i;
    }
    return -1;
}

void imprimirReporte(int *licenciaRep,int *cantidad,char **placa,double *monto,ofstream &archReporte,char car){
    
    if(car=='L') archReporte<<"FALTAS LEVES"<<endl;
    else if(car=='G') archReporte<<"FALTAS GRAVES"<<endl;
    else if(car=='M') archReporte<<"FALTAS MUY GRAVES"<<endl;
    imprimirLinea('=',MAX_LINEA,archReporte);
    archReporte<<"No."<<setw(15)<<"Licencia"<<setw(14)<<"Placa"<<setw(19)<<"Cantidad"<<setw(11)<<"Monto"<<endl;
    imprimirLinea('-',MAX_LINEA,archReporte);
    for(int i=0;placa[i];i++){
        archReporte<<setfill('0')<<setw(3)<<i+1<<")"<<setfill(' ')<<setw(14)<<licenciaRep[i]<<setw(15)<<placa[i]<<setw(14)<<cantidad[i]<<setw(15)<<monto[i]<<endl;
    }
    imprimirLinea('*',MAX_LINEA,archReporte);
}

void imprimirLinea(char car,int cant,ofstream &arch){
    for(int i=0;i<cant;i++){
        arch<<car;
    }
    arch<<endl;
}

void liberarMemoria(int *licenciaRep,int *cantidad,char **placa,double *monto){
    delete licenciaRep;
    delete cantidad;
    for(int i=0;placa[i];i++){
        delete placa[i];
    }
    delete placa;
    delete monto;
}