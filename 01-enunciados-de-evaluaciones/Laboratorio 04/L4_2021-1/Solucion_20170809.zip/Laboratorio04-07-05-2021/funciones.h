/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   funciones.h
 * Author: Alonso
 *
 * Created on 7 de mayo de 2021, 08:05 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H
#include <fstream>
using namespace std;

void cargarConductores(int *&,char **&);
char * leerNombreConductor(ifstream &);
void reporteConductores(int *,char **);
void cargarInfracciones(int *&,char *&,double *&);
char leerGravedad(ifstream &);
void reporteInfracciones(int *,char *,double *);
void reporteDeFaltas(int *,char **,int *,char *,double *);
void leerArchivo(int *&,int *&,char **&,double *&,int *,char *,double *,char );
char * leerPlaca(char *);
int buscarInfraccion(int *,int );
int buscaPlaca(char **,int ,char *);
void imprimirReporte(int *,int *,char **,double *,ofstream &,char );
void imprimirLinea(char ,int ,ofstream &);
void liberarMemoria(int *,int *,char **,double *);

#endif /* FUNCIONES_H */

