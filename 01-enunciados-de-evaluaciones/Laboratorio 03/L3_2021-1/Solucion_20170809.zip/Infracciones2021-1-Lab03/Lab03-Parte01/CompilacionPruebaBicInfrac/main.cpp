/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Alonso Oswaldo Acosta Gonzales
 * Codigo del Alumno: 20170809
 * Created on 30 de abril de 2021, 09:40 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
#include "StConductor.h"
#include "StFalta.h"
#include "StInfraccion.h"
#include "StInfraccionEstab.h"
#include "operadoresSobrecargados.h"

/*
 * 
 */
int main(int argc, char** argv) {

    TConductorSt conductor;
    
    ifstream archConductores("Conductores.txt",ios::in);
    if(!archConductores){
        cout<<"ERROR: NO se pudo abrir el archivo Conductores.txt"<<endl;
        exit(1);
    }
    
    ifstream archInfracciones("Infracciones.txt",ios::in);
    if(!archInfracciones){
        cout<<"ERROR: NO se pudo abrir el archivo Infracciones.txt"<<endl;
        exit(1);
    }

    ifstream archRegistroDeFallas("RegistroDeFallas.txt",ios::in);
    if(!archRegistroDeFallas){
        cout<<"ERROR: NO se pudo abrir el archivo RegistroDeFallas.txt"<<endl;
        exit(1);
    }
    
    ofstream archReporte("ReportePrueba.txt",ios::out);
    if(!archReporte){
        cout<<"ERROR: NO se pudo abrir el archivo ReportePrueba.txt"<<endl;
        exit(1);
    }

    TInfraccionSt infraccion;
    TInfraccionEstabSt infraccionEst;
    int fecha=20201225;
    
    archConductores>>conductor;
    archRegistroDeFallas>>infraccion;
    archInfracciones>>infraccionEst;
    
    conductor+infraccion;
    conductor+infraccionEst;
    ++conductor;
    conductor*fecha;
    ++conductor;
    
    archReporte<<conductor;
    
    return 0;
}

