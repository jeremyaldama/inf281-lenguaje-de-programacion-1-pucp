/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   StInfraccion.h
 * Author: Alonso
 *
 * Created on 30 de abril de 2021, 08:11 AM
 */

#ifndef STINFRACCION_H
#define STINFRACCION_H

typedef struct InfraccionSt{
    int licencia;
    char placa[10];
    int codInf;
    int fecha;
}TInfraccionSt;

#endif /* STINFRACCION_H */

