/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   operadoresSobrecargados.h
 * Author: Alonso
 *
 * Created on 30 de abril de 2021, 08:17 AM
 */

#ifndef OPERADORESSOBRECARGADOS_H
#define OPERADORESSOBRECARGADOS_H
#include <fstream>
using namespace std;
#include "StConductor.h"
#include "StFalta.h"
#include "StInfraccion.h"
#include "StInfraccionEstab.h"

bool operator >>(ifstream &, TConductorSt &);
bool operator >>(ifstream &, TInfraccionSt &);
bool operator >>(ifstream &, TInfraccionEstabSt &);
void operator +(TConductorSt &, const TInfraccionSt &);
void operator +(TConductorSt &,const TInfraccionEstabSt &);
void operator ++(TConductorSt &);
void operator *(TConductorSt &,int );
void eliminarFaltasLeves(TConductorSt &,int );
ofstream & operator <<(ofstream &, const TConductorSt &);
void imprimirLinea(char ,int ,ofstream &);

#endif /* OPERADORESSOBRECARGADOS_H */

