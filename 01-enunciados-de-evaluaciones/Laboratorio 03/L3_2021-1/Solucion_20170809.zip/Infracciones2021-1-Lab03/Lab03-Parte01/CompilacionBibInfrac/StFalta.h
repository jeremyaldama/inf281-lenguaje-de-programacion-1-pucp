/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   StFalta.h
 * Author: Alonso
 *
 * Created on 30 de abril de 2021, 08:09 AM
 */

#ifndef STFALTA_H
#define STFALTA_H

typedef struct FaltaSt{
    char placa[10];
    int fecha;
    int codInf;
    double multa;
    char gravedad[20];
}TFaltaSt;

#endif /* STFALTA_H */

