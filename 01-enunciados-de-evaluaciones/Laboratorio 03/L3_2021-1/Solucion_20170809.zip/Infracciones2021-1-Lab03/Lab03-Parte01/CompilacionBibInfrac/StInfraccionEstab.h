/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   StInfraccionEstab.h
 * Author: Alonso
 *
 * Created on 30 de abril de 2021, 08:14 AM
 */

#ifndef STINFRACCIONESTAB_H
#define STINFRACCIONESTAB_H

typedef struct InfraccionEstabSt{
    int codigo;
    char gravedad[20];
    double multa;
}TInfraccionEstabSt;

#endif /* STINFRACCIONESTAB_H */

