/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   StConductor.h
 * Author: Alonso
 *
 * Created on 30 de abril de 2021, 08:05 AM
 */

#ifndef STCONDUCTOR_H
#define STCONDUCTOR_H
#include "StFalta.h"

typedef struct ConductorSt{
    int licencia;
    char nombre[100];
    struct FaltaSt faltas[20];
    int numFaltas;
    int numFaltasLeves;
    int numFaltasGraves;
    int numFaltasMuyGraves;
    double montoFaltasLeves;
    double montoFaltasGraves;
    double montoFaltasMuyGraves;
}TConductorSt;

#endif /* STCONDUCTOR_H */

