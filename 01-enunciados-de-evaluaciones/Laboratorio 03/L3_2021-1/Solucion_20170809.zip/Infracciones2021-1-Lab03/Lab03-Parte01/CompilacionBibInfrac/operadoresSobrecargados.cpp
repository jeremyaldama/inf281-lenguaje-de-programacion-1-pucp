/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
using namespace std;
#include "StConductor.h"
#include "StFalta.h"
#include "StInfraccion.h"
#include "StInfraccionEstab.h"
#include "operadoresSobrecargados.h"
#define MAX_LINEA 200

bool operator >>(ifstream &inArch, TConductorSt &conductor){
    inArch>>conductor.licencia;
    if(inArch.eof()) return false;
    inArch>>conductor.nombre;
    conductor.numFaltas=0;
    conductor.numFaltasLeves=0;
    conductor.numFaltasGraves=0;
    conductor.numFaltasMuyGraves=0;
    conductor.montoFaltasLeves=0.0;
    conductor.montoFaltasGraves=0.0;
    conductor.montoFaltasMuyGraves=0.0;
    return true;
}

bool operator >>(ifstream &inArch, TInfraccionSt &conductor){
    int dd,mm,aa;
    char car;
    inArch>>conductor.licencia;
    if(inArch.eof()) return false;
    inArch>>conductor.placa>>dd>>car>>mm>>car>>aa>>conductor.codInf;
    conductor.fecha=aa*10000+mm*100+dd;
    return true;
}

bool operator >>(ifstream &inArch, TInfraccionEstabSt &infraccionEst){
    char descripcion[250];
    inArch>>infraccionEst.codigo;
    if(inArch.eof()) return false;
    inArch>>descripcion>>infraccionEst.gravedad>>infraccionEst.multa;
    return true;
}

void operator +(TConductorSt &conductor, const TInfraccionSt &infraccion){
    if(conductor.licencia==infraccion.licencia){
        conductor.faltas[conductor.numFaltas].codInf=infraccion.codInf;
        conductor.faltas[conductor.numFaltas].fecha=infraccion.fecha;
        strcpy(conductor.faltas[conductor.numFaltas].placa,infraccion.placa);
        conductor.numFaltas++;
    }
}

void operator +(TConductorSt &conductor,const TInfraccionEstabSt &infraccionEst){
    for(int i=0;i<conductor.numFaltas;i++){
        if(conductor.faltas[i].codInf==infraccionEst.codigo){
            strcpy(conductor.faltas[i].gravedad,infraccionEst.gravedad);
            conductor.faltas[i].multa=infraccionEst.multa;
        }
    }
}

void operator ++(TConductorSt &conductor){
    conductor.numFaltasLeves=0;
    conductor.numFaltasGraves=0;
    conductor.numFaltasMuyGraves=0;
    conductor.montoFaltasLeves=0;
    conductor.montoFaltasGraves=0;
    conductor.montoFaltasMuyGraves=0;
    for(int i=0;i<conductor.numFaltas;i++){
        if(strcmp(conductor.faltas[i].gravedad,"Leve")==0){
            conductor.numFaltasLeves++;
            conductor.montoFaltasLeves+=conductor.faltas[i].multa;
        }
        else if(strcmp(conductor.faltas[i].gravedad,"Grave")==0){
            conductor.numFaltasGraves++;
            conductor.montoFaltasGraves+=conductor.faltas[i].multa;
        }
        else if(strcmp(conductor.faltas[i].gravedad,"Muy_Grave")==0){
            conductor.numFaltasMuyGraves++;
            conductor.montoFaltasMuyGraves+=conductor.faltas[i].multa;
        }
    }
}

void operator *(TConductorSt &conductor,int fecha){
    for(int i=0;i<conductor.numFaltas;i++){
        if(conductor.faltas[i].fecha<=fecha){
            if(strcmp(conductor.faltas[i].gravedad,"Leve")==0){
                eliminarFaltasLeves(conductor,i);
                i--;
            }
            else if(strcmp(conductor.faltas[i].gravedad,"Grave")==0){
                conductor.faltas[i].multa*=0.75;
            }
            else if(strcmp(conductor.faltas[i].gravedad,"Muy_Grave")==0){
                conductor.faltas[i].multa*=0.92;
            }
        }
    }
    //Para recalcular los montos totales usamos ++conductor
    //Pero el profesor quizo que lo hagamos aparte, o sea, afuera de esta sobrecarga
    //Llamando a ++conductor
}

void eliminarFaltasLeves(TConductorSt &conductor,int k){
    for(int i=k;i<conductor.numFaltas-1;i++){
        conductor.faltas[i]=conductor.faltas[i+1]; //copiamos las struct, operacion valida
    }
    conductor.numFaltasLeves--;
    conductor.numFaltas--;
}

ofstream & operator <<(ofstream &outArch,const TConductorSt &conductor){
    
    int dd,mm,aa,fechaAux;
    
    outArch.precision(2);
    outArch<<fixed;
    
    outArch<<"Conductor: "<<conductor.nombre<<endl;
    outArch<<"Licencia No.: "<<conductor.licencia<<endl;
    imprimirLinea('=',MAX_LINEA,outArch);
    outArch<<"Infracciones cometidas: "<<endl;
    imprimirLinea('-',MAX_LINEA,outArch);
    outArch<<"No."<<setw(15)<<"Fecha"<<setw(20)<<"Placa"<<setw(20)<<"Infraccion"<<setw(20)<<"Gravedad"<<setw(20)<<"Multa"<<endl;
    for(int i=0;i<conductor.numFaltas;i++){
        aa=conductor.faltas[i].fecha/10000;
        fechaAux=conductor.faltas[i].fecha%10000;
        mm=fechaAux/100;
        dd=fechaAux%100;
        outArch<<setw(2)<<i+1<<")"<<setw(10)<<" "<<setfill('0')<<setw(2)<<dd<<"/"<<setw(2)<<mm<<"/"<<setw(4)<<aa<<setfill(' ')<<setw(17)<<conductor.faltas[i].placa
                <<setw(14)<<conductor.faltas[i].codInf<<setw(17)<<" "<<left<<setw(20)<<conductor.faltas[i].gravedad<<right<<setw(8)<<conductor.faltas[i].multa<<endl;
    }
    imprimirLinea('=',MAX_LINEA,outArch);
    outArch<<setw(35)<<"Cantidad"<<setw(15)<<"Total"<<endl;
    outArch<<left<<setw(25)<<"Infracciones leves: "<<right<<setw(8)<<conductor.numFaltasLeves<<setw(17)<<conductor.montoFaltasLeves<<endl;
    outArch<<left<<setw(25)<<"Infracciones graves: "<<right<<setw(8)<<conductor.numFaltasGraves<<setw(17)<<conductor.montoFaltasGraves<<endl;
    outArch<<left<<setw(25)<<"Infracciones muy graves: "<<right<<setw(8)<<conductor.numFaltasMuyGraves<<setw(17)<<conductor.montoFaltasMuyGraves<<endl;
    imprimirLinea('=',MAX_LINEA,outArch);
}

void imprimirLinea(char car,int cant,ofstream &arch){
    for(int i=0;i<cant;i++){
        arch<<car;
    }
    arch<<endl;
}




