/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   funciones.h
 * Author: Alonso
 *
 * Created on 30 de abril de 2021, 09:45 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H
#include <fstream>
using namespace std;
#include "StConductor.h"
#include "StFalta.h"
#include "StInfraccion.h"
#include "StInfraccionEstab.h"
#include "operadoresSobrecargados.h"

void leerConductores(TConductorSt *conductor,int &numConductores);
void leerFaltas(TConductorSt *conductor,int numConductores);
void emitirReporte(TConductorSt *conductor,int numConductores);

#endif /* FUNCIONES_H */

