/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
#include "StConductor.h"
#include "StFalta.h"
#include "StInfraccion.h"
#include "StInfraccionEstab.h"
#include "operadoresSobrecargados.h"
#include "funciones.h"

void leerConductores(TConductorSt *conductor,int &numConductores){
    ifstream archConductores("Conductores.txt",ios::in);
    if(!archConductores){
        cout<<"ERROR: NO se pudo abrir el archivo Conductores.txt"<<endl;
        exit(1);
    }
    
    while(1){
        archConductores>>conductor[numConductores];
        if(archConductores.eof()) break;
        conductor[numConductores].numFaltas=0;
        numConductores++;
    }
}

void leerFaltas(TConductorSt *conductor,int numConductores){
    ifstream archRegistroDeFallas("RegistroDeFallas.txt",ios::in);
    if(!archRegistroDeFallas){
        cout<<"ERROR: NO se pudo abrir el archivo RegistroDeFallas.txt"<<endl;
        exit(1);
    }
    
    TInfraccionSt infraccion;
    
    for(int i=0;i<numConductores;i++){
        archRegistroDeFallas>>infraccion;
        if(archRegistroDeFallas.eof()) break;
        conductor[i]+infraccion;
    }
    
}

void emitirReporte(TConductorSt *conductor,int numConductores){
    
    ofstream archReporte("Reporte.txt",ios::out);
    if(!archReporte){
        cout<<"ERROR: NO se pudo abrir el archivo ReportePrueba.txt"<<endl;
        exit(1);
    }
    
    for(int i=0;i<numConductores;i++){
        archReporte<<conductor[i];
    }
}